<?php
#ini_set('display_errors',1);
include('_projectID.php');

#reset opcache so credentials.php is read if just created
if(function_exists("opcache_reset")){
    opcache_reset();
}


if (array_key_exists('send', $_POST)  && $_POST['send']==1) {
    $content='<?php
	// first define the host, the database name, the username (admin), and the password
	define ("HOST","'.$_POST['host'].'");
	define ("ADMIN","'.$_POST['admin'].'");
	define ("DBNAME","'.$_POST['dbname'].'");
	define ("PASSW","'.$_POST['passw'].'");
	    ';

    if (!file_put_contents('credentials.php',$content)){
        ?>
        <html><head>
            <link href="resources/basis/newlayout.css" rel="stylesheet" type="text/css"  />
            <link href="resources/basis/newlayout_bootstrap.css" rel="stylesheet" type="text/css"  />
            <link href="resources/basis/grid.css" rel="stylesheet" type="text/css"  />
        </head>
        <body>
        <div class="alert alert-danger">
            <b>Credentials could not be written.</b> Permission to edit/write credentials.php is missing.<br>
            If you are using Bitnami give all users the right to read and write credentials.php.
            In Filezilla, find the file <i>credentials.php</i> in the folder of your experiment.
            Right-click on this file, and select <i>File permissions...</i>.
            A dialog box will open. Make sure that the <i>Read</i> and <i>Write</i> boxes are checked for <i>Public permissions</i>.<br>
            Once you have given these writing permissions to credentials.php, please refresh this screen and try again!<br>
            For more information please refer to the
            <a href="https://lioness-doc.readthedocs.io/en/latest/0303_set_up.html#set-up-your-database-and-lioness-tables" target="_blank">documentation!</a>
            If you require further help, please refer to the <a href="https://groups.google.com/forum/#!forum/lioness-lab" target="_blank"> forum.</a>.
        </div>
        </body>
        </html>
        <?php
        die();
    }

}
if(!file_exists('credentials.php')){
    $writer = fopen('credentials.php', 'w');
    if(!$writer){
        ?>
        <html><head>
            <link href="resources/basis/newlayout.css" rel="stylesheet" type="text/css"  />
            <link href="resources/basis/newlayout_bootstrap.css" rel="stylesheet" type="text/css"  />
            <link href="resources/basis/grid.css" rel="stylesheet" type="text/css"  />
        </head>
        <body>
        <div class="alert alert-danger">
            <b>Credentials could not be written.</b> Permission to create credentials.php in the game folder is missing.<br>
            If you are using Bitnami give all users the right to read and write into the game folder recursively.
            In Filezilla, find the folder of your experiment.
            Right-click on this folder, and select <i>File attributes...</i>.
            A dialog box will open. Make sure that the <i>Read</i> and <i>Write</i> boxes are checked for <i>Public permissions</i>.
            Also make sure that <i>Recurse into subdirectories</i> is checked.<br>
            Once you have given these writing permissions to credentials.php, please refresh this screen and try again!<br>
            For more information please refer to the
            <a href="https://lioness-doc.readthedocs.io/en/latest/0303_set_up.html#set-up-your-database-and-lioness-tables" target="_blank">documentation!</a>
            If you require further help, please refer to the <a href="https://groups.google.com/forum/#!forum/lioness-lab" target="_blank"> forum.</a>.
        </div>
        </body>
        </html>
        <?php
        die();
    }else{
        //write empty credentials file here
        fwrite($writer, '<?php 
    define ("HOST","localhost");
	define ("ADMIN","root");
	define ("DBNAME","lionessdb");
	define ("PASSW","");');
        fclose($writer);
    }
}

include('credentials.php');

$conn=mysqli_connect(HOST,ADMIN,PASSW,DBNAME);

if (!$conn || HOST=='' || DBNAME=='' || ADMIN=='') {

    if (DBNAME=='') $dbname='lionessdb';
    else $dbname=DBNAME;
    if (HOST=='') $host='localhost';
    else $host=HOST;
    if (ADMIN=='') $admin='root';
    else $admin=ADMIN;


    if (!$conn) {
        $error=mysqli_connect_errno();
        if ($error==1049 && DBNAME!='') {

            $conn2=mysqli_connect(HOST,ADMIN,PASSW);

            $sql = "CREATE DATABASE ".DBNAME;
            $result = mysqli_query($conn2, $sql);



        }

    } else $conn2=true;

    ?>

    <html><head>
        <link href="resources/basis/newlayout.css" rel="stylesheet" type="text/css"  />
        <link href="resources/basis/newlayout_bootstrap.css" rel="stylesheet" type="text/css"  />
        <link href="resources/basis/grid.css" rel="stylesheet" type="text/css"  />
    </head>
    <body>


    <div class="row-fluid" style="margin-left:50px;margin-right:50px;"><div class="span1"></div><div class="span4">
            <h3>Login Data for DB</h3>
            <div class="alert alert-danger">
                LIONESS cannot connect to the database, as it has not been created yet. <br>Please check whether your credentials are filled out correctly and press submit to generate the database.<br>
                If you are using the Bitnami Launchpad, you can find your password in the <i>Application Info</i> of your LAMP stack, in the field <i>Credentials</i>.<br>
                For the other fields LIONESS tried to add sensible default values.
                For more information please refer to the
                <a href="https://lioness-doc.readthedocs.io/en/latest/0303_set_up.html#set-up-your-database-and-lioness-tables" target="_blank">documentation!</a><br>
                <?php
                if (!$conn2) {

                    echo "Error of the database: " . mysqli_connect_error() . PHP_EOL;
                    echo "Error number: " . mysqli_connect_errno() . PHP_EOL;
                }

                ?>
            </div>
            <form method="post">
                <div class="form-group">
                    <label for="field1">Hostname</label>
                    <input name="host" id="field1"
                           type="text"
                           value="<?php echo $host; ?>"
                           class="form-control input-lg" style="text-align: center;">
                </div>
                <div class="form-group">
                    <label for="field2">Username</label>
                    <input name="admin" id="field2"
                           type="text"
                           value="<?php echo $admin; ?>"
                           class="form-control input-lg" style="text-align: center;">
                </div>
                <div class="form-group"><label for="field3">Password</label>
                    <input name="passw" id="field3"
                           type="text"
                           value="<?php echo PASSW; ?>"
                           class="form-control input-lg" style="text-align: center;">
                </div>
                <div class="form-group">
                    <label for="field4">Database</label>
                    <input name="dbname" id="field4"
                           type="text"
                           value="<?php echo $dbname; ?>"
                           class="form-control input-lg" style="text-align: center;">
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
                <input name="send" type="hidden"
                       value="1"
                >
            </form>
        </div></div>
    </body>


    </html>


    <?php

} else {
    $compiled=false;
    $sql2 = "SHOW TABLES ";
    $result = mysqli_query($conn, $sql2);
    $correctab=0;
    while ($row=mysqli_fetch_array($result,MYSQLI_NUM)) {

        if ($row[0]==PROJECTID.'core') $correctab++;
        if ($row[0]==PROJECTID.'globals') $correctab++;
        if ($row[0]==PROJECTID.'decisions') $correctab++;
        if ($row[0]==PROJECTID.'session') $correctab++;
        if ($row[0]==PROJECTID.'logevents') $correctab++;
    }

    if ($correctab==5) $compiled=true;
    if ($compiled) {
        header('Location: _beginControl.php');
    } else {

        $sql = file_get_contents('setup_tables.sql');
        $lines=explode(';SELECT 1;',$sql);
        foreach ($lines as $line) {
            $result = mysqli_query($conn, $line);
        }
        header('Location: _beginControl.php');
    }



}
