<?php
	include('sql_library.php');	
	$tableName=$_GET['tableName'];
	$condition=$_GET['condition'];
	$varName=$_GET['varName'];
	$value = getValue($tableName, $condition, $varName);
	echo json_encode($value, JSON_NUMERIC_CHECK);
