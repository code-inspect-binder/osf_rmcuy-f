<?php
ini_set('display_errors',0);


if (isset($_GET['m'])) {
    $message=base64_decode($_GET['m']);
    $paramarray=unserialize($message);

    $messageNr=$paramarray['messageNr'];
    $playerNr=$paramarray['playerNr'];
    $projectID=$paramarray['projectID'];

}
else $messageNr=-1;

define("PROJECTID",$projectID);
include("../_projectID.php");
include("sessionStart.php");
include("sql_library.php");

// message 0 = HIT is offline ('sessionOffline.php')
// message 1 = duplicate participant ('devicePresent.php')
// message 2 = HIT is full    ('HITfull.php')
// message 3 = no player cookie found ('notLoggedIn.php')
// message 4 = HIT terminated ('HITterminated.php')
// message 5 = HIT timed out ('HITendedTimeout.php')
// message 6 = Group was aborted ('HITendedTimeout.php')
// message 7 = browser (IE) not supported ('browserNotSupported.php')
// message 8 = quiz fails
$parName = 'message' . $messageNr;
if ($messageNr==-1 || $messageNr>8) $messageText="An error occurred. You cannot access this page.";
else $messageText=readParameter($parName);
?>
<html>
<head>
    <title>Experiment stopped</title>
    <link rel="shortcut icon"  href="logo-head.png">
    <link rel="stylesheet" type="text/css" href="mystyle.css">
    <link href="newlayout.css" rel="stylesheet" type="text/css"  />
    <link href="newlayout_bootstrap.css" rel="stylesheet" type="text/css"  />
    <script src="<?php echo PATH; ?>jquery.js"></script>
    <script src="LIONESS_lib.js?v5" type="text/javascript"></script>
</head>
<body>
<script>
    //    clearInterval(connect); // stop telling the server that this participant is still active
    var messageText = <?php echo json_encode($messageText); ?>;
    var messageNr = <?php echo json_encode($messageNr, JSON_NUMERIC_CHECK); ?>;
    var playerNr = <?php echo json_encode($playerNr, JSON_NUMERIC_CHECK); ?>;
    var path = "";

    if (messageNr==4 || messageNr==6){
        var participationFee=getParameter('participationFee');
        var randomid =  getValue('session', 'playerNr='+playerNr, 'randomidNotPlayed');
//        alert(randomid);
        if (messageNr==4) setValue('core', 'playerNr='+playerNr, 'onPage','TERMINATED');
        if (messageNr==6) setValue('core', 'playerNr='+playerNr, 'onPage','GROUP ABORTED');

        setValue('core', 'playerNr='+playerNr, 'connected',0);

        setValue('session', 'playerNr='+playerNr, 'relevantRandomid',randomid);
        if (messageNr==4)  setValue('session', 'playerNr='+playerNr, 'bonusAmount', 0);
        if (messageNr==6) {
            var bonus = 0;
            for (var i=1; i<=period; i++) {
                bonus = bonus + getInt('decisions', 'playerNr='+playerNr+' and period='+i, 'payoffThisPeriod');
            }
            setValue('session', 'playerNr='+playerNr, 'bonusAmount', bonus);
        }

        setValue('session', 'playerNr='+playerNr, 'participationAmount', participationFee);

        setValue('session', 'playerNr='+playerNr, 'totalEarnings', participationFee);
    }

    //document.write('<div class="alert alert-warning" style="text-align: center; margin-top: 50px;">'+messageText+'</div>');
</script>
<?php
$suchmuster='/(\$)([.a-zA-Z0-9_]*)(\$)/';

 $output=preg_replace_callback(
    $suchmuster,
    function ($treffer) {

        return '<script>document.write('.$treffer[2].')</script>';

    },
    $messageText);
echo '<div class="alert alert-warning" style="text-align: center; margin-top: 50px;">';

echo html_entity_decode($output);

echo '</div>'

?>

</body>

</html>
