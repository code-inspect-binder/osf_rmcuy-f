/**
 * Created by Marcus on 31.07.2016.
 */



$(document).click(function() {

});
function terminatePlayer(playerNr){
    if (typeof playerNr != undefined && playerNr!=null && playerNr!='') {

        return $.ajax({
            type: 'POST',
            async: true,
            url: 'terminatePlayer.php',
            cache: false,
            data: ({
                playerNr: playerNr
            }),
            success: function (result) {

                showMessage('Player '+playerNr+' terminated.');
                //else showMessage('Player '+playerNr+ ' does not exist or was already terminated.');


            }
        });


    } else {

    }
}
path='';

function switchTestMode(switcher) {

    var container=$('#testmode');
    var testplayer=$('#testplayer');
    var testbot=$('#testbot');
    var testplayer_off=$('#testplayer_off');
    var testbot_off=$('#testbot_off');
    let testMode=getParameter('testMode');

    if ((testMode==0 && switcher==true)||(testMode==1 && switcher==false)) {
        if (switcher) setValue('globals','name="testMode"','value',1);
        container.addClass('btn-success');
        container.html('test mode on');

        testplayer.show();
        testbot.show();
        testplayer_off.hide();
        testbot_off.hide();


    } else {
        if (switcher) setValue('globals','name="testMode"','value',0);
        container.removeClass('btn-success');
        container.html('test mode off');
        testplayer_off.show();
        testbot_off.show();
        testplayer.hide();
        testbot.hide();
    }

}

function switchActive(switcher) {
    var container=$('#gameactive');

    active=getParameter('active');

    if ((active==0 && switcher==true)||(active==1 && switcher==false)) {
        if (switcher) setValue('globals','name="active"','value',1);
        container.addClass('btn-success');
        container.html('experiment active');


    } else {
        if (switcher) setValue('globals','name="active"','value',0);
        container.removeClass('btn-success');
        container.html('experiment inactive');

    }

}

function fileExists(url) {
    if(url){
        var req = new XMLHttpRequest();
        req.open('GET', url, false);
        req.send();
        return req.status==200;
    } else {
        return false;
    }
}

function getParameter(name) {


    return JSON.parse($.ajax({
        type: 'GET',
        async: false,
        url: 'getData.php',
        data: {tableName: 'globals', condition: 'name="'+name+'"', varName:'value'},
        success: function(data) {
            return data;
        }
    }).responseText);



}

function showMessage(message) {



    var container=$('#messages');
    var body=$("#message_body");
    body.addClass('alert alert-warning');
    body.html(message);
    container.show();
    container.delay(10000).fadeOut(800);

}

function emptyDataTables(projectID){
    var xmlhttp;
    if (window.XMLHttpRequest) {xmlhttp = new XMLHttpRequest();}
    else {xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");}
    xmlhttp.open("POST", "emptydatatables.php?projectID =" + projectID);
    xmlhttp.send();
}
