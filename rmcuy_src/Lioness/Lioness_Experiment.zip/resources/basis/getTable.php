<?php
include('sql_library.php');
$tableName=$_GET['tableName'];
$varName=$_GET['varName'];
$value = getTable($tableName);
echo json_encode($value, JSON_NUMERIC_CHECK | JSON_FORCE_OBJECT );
