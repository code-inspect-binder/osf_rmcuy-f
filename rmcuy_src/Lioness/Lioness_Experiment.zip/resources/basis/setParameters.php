<?php
	include("sql_library.php");
	$con=mysqli_connect(HOST,ADMIN,PASSW,DBNAME);
	if (mysqli_connect_errno()) {echo "Failed to connect to MySQL: " . mysqli_connect_error();};// Check connection
	// empty the parameter table and write the entered value in
	$sql = "SELECT * FROM ".PROJECTID."globals";
	$result= mysqli_query($con,$sql); 
	$vnames=[]; 
	while ($row=mysqli_fetch_array($result)) 
	{
		$vnames[]=$row['name'];
	}
	// CREATE ALL TABLES IN THE NEW DATABASE
	$sql="TRUNCATE ".PROJECTID."globals";
	if (mysqli_query($con,$sql)) {$tableCreateMess = "Table created successfully";} 
	else {$tableCreateMess = "Error creating table: " . mysqli_error($con);}
	$sql="INSERT INTO `" . PROJECTID."globals` (`name`, `value`) VALUES ";
	$validEntries=[];
	for ($i=0; $i<count($vnames); $i++)
	{
		$val = $_REQUEST[$vnames[$i]];
		if ($val != "-") $validEntries[]=1;
		else $validEntries[]=0;
	}
	for ($i=0; $i<count($vnames); $i++)
	{
		if ($validEntries[$i]==1)
		{
			$val = $_REQUEST[$vnames[$i]];
			$sql.= "('" . $vnames[$i] . "', '" . $val ."')";
			$varsLeft = array_sum(array_slice($validEntries, $i));
			if ($varsLeft > 1) $sql .=",";
		}
	}
	// Execute query and report the result
	if (mysqli_query($con,$sql)) {$tableCreateMess = "Table created successfully";} 
	else {$tableCreateMess = "Error creating table: " . mysqli_error($con);}

	header("Location: _beginControl.php");
	exit();


