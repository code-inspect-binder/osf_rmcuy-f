<?php
	include('sql_library.php');
	$tableName=$_GET['tableName'];
	$condition=$_GET['condition'];
	$varName=$_GET['varName'];
	$sortBy=$_GET['sortBy'];
	$values = getValues($tableName, $condition, $varName, $sortBy);
	echo json_encode($values, JSON_NUMERIC_CHECK);