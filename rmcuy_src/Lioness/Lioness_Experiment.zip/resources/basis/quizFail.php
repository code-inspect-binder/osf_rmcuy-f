<?php
	include("sql_library.php");
    $playerNr = $_GET['playerNr'];

    if ($_GET['readonly']!=1) {
        $failures = getValue("session", "playerNr=$playerNr", "quizFail");
        setValue("session", "playerNr=$playerNr", "quizFail", ($failures + 1));

        if ($_GET['wronganswers']!=null) {

            foreach ($_GET['wronganswers'] as $label=>$wasfalse) {
                if ($wasfalse==1) {
                    $failures_this = getValue("session", "playerNr=$playerNr", $label . "_fail");
                    setValue("session", "playerNr=$playerNr", $label . "_fail", ($failures_this + 1));
                }
            }



        }


    }


	echo getValue("session","playerNr=$playerNr","quizFail");
