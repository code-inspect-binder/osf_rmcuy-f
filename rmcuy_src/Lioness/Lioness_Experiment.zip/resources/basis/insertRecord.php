<?php
	include('sql_library.php');
	$tableName=$_REQUEST['tableName'];
	$varNames=json_decode(stripslashes($_REQUEST['varNames']));//$_REQUEST['varNames'];
	$values=json_decode(stripslashes($_REQUEST['values'])); //$_REQUEST['values'];
	insertRecord($tableName, $varNames, $values);
