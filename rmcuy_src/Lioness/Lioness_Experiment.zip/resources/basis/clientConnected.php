<?php
// record time on server (if client is still active)
$playerNr = $_GET['playerNr'];
require('sessionStart.php');
define("PROJECTID",$_SESSION['projectID']);
session_write_close();
if (file_exists('../../credentials.php')) include('../../credentials.php');
elseif (file_exists('../../../credentials.php')) include('../../../credentials.php');
else include('credentials.php');

$table_name_server = PROJECTID . "core";
$conn=mysqli_connect(HOST,ADMIN,PASSW,DBNAME) or die(mysqli_error());
$sql="UPDATE ".$table_name_server." SET lastActionTime = ".time()." WHERE (playerNr=".$playerNr.")";
$result=@mysqli_query($conn, $sql) or die("Couldn't execute query ".$sql);

//include('controller_algorithm.php');