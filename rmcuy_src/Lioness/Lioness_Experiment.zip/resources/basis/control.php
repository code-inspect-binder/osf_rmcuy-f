<?php
$path = PATH . 'basis/';
include('Login.class.php');
if (isset($_GET['logout'])) {

    LoginLioness::logout(null, '_beginControl.php');
}
// load the library to regulate reading from and writing to the database
setcookie('projectID', PROJECTID);

include('sql_library.php');
// read the parameter values from the server
$conn = mysqli_connect(HOST, ADMIN, PASSW, DBNAME) or die(mysqli_error());
/* disable strict mode in mysql if enabled (for example google cloud computing)*/
$sql = 'SELECT @@GLOBAL.sql_mode;';
$result = @mysqli_query($conn, $sql) or die("Couldn't execute query " . $sql);

$originalResult = explode(",", mysqli_fetch_array($result)[0]);
$result = array_diff($originalResult, ["STRICT_TRANS_TABLES"]);
$result = array_diff($result, ["STRICT_ALL_TABLES"]);
$originalResult = implode(",", $originalResult);
$result = implode(",", $result);

if (strlen($originalResult) != strlen($result)) {
    $sql = 'set GLOBAL sql_mode = "' . $result . '"';
    if (!mysqli_query($conn, $sql)) {
        printf("Errormessage: %s\n", mysqli_error($conn));
    }
}


$sql = "SELECT * FROM " . PROJECTID . "globals";
$result = @mysqli_query($conn, $sql) or die("Couldn't execute query " . $sql);
$vnames = [];
$vvals = [];
while ($row = mysqli_fetch_array($result)) {
    $vnames[] = $row['name'];
    $vvals[] = $row['value'];
}
require(PATH . 'pagination/Pagination.class.php');
$page = new Pagination(PATH);

echo $page->getHead();

//	print_r($_SESSION['stageNames']);

//	print_r($_SESSION['stageNum']);

?>


    <base href="<?php echo $path; ?>"/>
    <link rel="shortcut icon" href="logo-head.png">

<?php
if (defined('PROJECTPW')) $pw = PROJECTPW;
else $pw = -1;

if (LoginLioness::checkValidity($pw)) {
    ?>

    <script>

        function checkEssentialParameters() {
            /* check if the entries are valid */
            var essentialParameters = ['totalPlayers', 'groupSize', 'numberPeriods'];
            var enteredVariables = document.forms["parameterForm"].elements;
            for (var i = 0; i < essentialParameters.length; i++) {
                var val = enteredVariables[i].value;
                if (val == null || val == "" || isNaN(val) || val == '-') {
                    alert('A variable ' + essentialParameters[i] + ' MUST be set!');
                    return false;
                }
            }
            return true;
        }

        var controllerAlgWorker;

        function registerControllerAlgWorker() {
            if (typeof(Worker) !== "undefined") {
                if (typeof(controllerAlgWorker) == "undefined") {
                    controllerAlgWorker = new Worker("callController.js");
                    controllerAlgWorker.onmessage = function (event) {
                        document.getElementById("controllerDone").innerHTML = '<font size="1">t<sub>PHP</sub>=' + event.data;
                        document.getElementById("heart").style.opacity = "0.5";
                        setTimeout(function () {
                            document.getElementById("heart").style.opacity = "1";
                        }, 500)
                    };
                    controllerAlgWorker.onerror = function (event) {
                        console.log(event.data);
                    };
                    controllerAlgWorker.postMessage("<?php echo PROJECTID;?>");
                } else {
                    console.log("Web Worker is already defined");
                }

            } else {
                alert("Sorry, your browser does not support Web Workers...");
            }
        };
        registerControllerAlgWorker();
    </script>
    </head>

    <?php

    $idExperimenter = explode('g', PROJECTID);
    $idExperimenter = ltrim($idExperimenter[0], 'e');
    if ($idExperimenter > 10000) $isDemo = true;
    else $isDemo = false;

    echo $page->getTopNavigation(PROJECTID, $isDemo);
    echo $page->getNavBar();
    echo $page->beginContainer();

    if ($isDemo) echo '<div class="alert alert-warning">Welcome to this LIONESS demo experiment. Please start test players (or bots) using the top horizontal bar. You can monitor the progress of the experiment below, and select the variables you wish to track by clicking \'Display options.\'</div>';

    $cookie = array_key_exists('controlbanner', $_COOKIE) ? $_COOKIE['controlbanner'] : null;
    if ($cookie != 1) {
        echo '<div id="controlbanner"><div class="alert alert-info" style="margin-bottom: 2px; margin-top: 5px;">This page controls the experimental flow. Keep this page open for the entire duration of your interactive experiment. For non-interactive experiments this page does not need to be open.</div>';
        echo '<div class="row-fluid">';
        if (!$isDemo && ($_SERVER['HTTP_HOST'] == 'lioness.uni-passau.de' || $_SERVER['HTTP_HOST'] == 'classex.uni-passau.de')) echo '<div style="padding-left: 5px; font-size: x-small; color: gray" class="span10">You are running your experiment on lioness.uni-passau.de. This server is mainly for development and testing. To prevent overload, we cap the maximum number of participants on this server to 100. When you are finished developing and testing, and ready to run your experiment, please <a href="https://lioness-doc.readthedocs.io/en/latest/0303_set_up.html" target="_blank">download your experiment and put it on an own server</a>.</div>';
        else echo '<div class="span10"></div>';

        echo '<div class="span2" onclick=" var d=new Date(); 
                    d.setTime(d.getTime() + (365*24*60*60*1000)); 
                    document.cookie=\'controlbanner=1; expires=\' + d.toUTCString(); 
                    $(\'#controlbanner\').hide();" style="cursor: pointer;  padding-right: 5px; text-align: right; color: grey; font-size: x-small">Do not show this hint again</div>';


        echo '</div></div>';
    }
    ?>


    <div class="row-fluid">


        <div id="monitor" class="span12">

            <?php
            include($path . "monitor.php");
            ?>


        </div>
    </div>

    </div>


    <?php

    echo $page->endContainer();

} else {

    LoginLioness::displayLoginField();
}
echo $page->getBodyEnd();