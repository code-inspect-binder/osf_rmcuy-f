<?php
	
	include('sql_library.php');
	$parName=$_GET['parName'];

	$value = readParameter($parName);
	echo json_encode($value, JSON_NUMERIC_CHECK);