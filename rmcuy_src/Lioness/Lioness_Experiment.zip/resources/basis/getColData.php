<?php
include('sql_library.php');
$tableName=$_GET['tableName'];
$condition=$_GET['condition'];
$varNames=$_GET['varNames'];
$sortBy=$_GET['sortBy'];
$values = getColValues($tableName, $condition, $varNames, $sortBy);
echo json_encode($values, JSON_NUMERIC_CHECK);
