<?php

	include('_projectID.php');
	$path2=PATH."basis/sessionStart.php";
	include($path2);
	$_SESSION['projectID']=PROJECTID;
	include('_stageNames.php');

	$path=PATH."basis/control.php";
	include($path);

?>