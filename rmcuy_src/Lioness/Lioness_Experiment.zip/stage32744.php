<html>
        <head>
        <?php
  
        include("_projectID.php");
        session_start();
	    $_SESSION['projectID']=PROJECTID;
	    include(PATH."basis/LIONESS.php");
	    ?>

        <link href="<?php echo PATH;?>basis/newlayout.css" rel="stylesheet" type="text/css"  />
        <link href="<?php echo PATH;?>basis/newlayout_bootstrap.css" rel="stylesheet" type="text/css"  />
        <link href="<?php echo PATH;?>basis/grid.css" rel="stylesheet" type="text/css"  /><title>end of round TP</title>

        <script> var v={}; var wronganswers={};var maxFalse = null;
        var firstStageExp = <?php echo json_encode(FIRSTPAGE . ".php"); ?>;
        var thisPage = <?php echo json_encode($thisPage); ?>;
      
        pageRefreshed=0;
        var loopBegin = "stage" + loopStart + ".php";
        var afterLoopEnd = 32743;
        if (thisPage == firstStageExp || (thisPage==loopBegin && period > 1) || loopEnd==afterLoopEnd) firstStage();
        /* if (thisPage == firstStageExp || thisPage==loopBegin || loopEnd==afterLoopEnd) firstStage(); */
        TimeOut=15;
        function skipStage() {
         location.replace('wait32744.php?session_index=<?php echo $_SESSION[sessionID];?>');
        }
        $(document).ready(function(){
        if (bot) { document.getElementsByClassName("buttonclick")[0].click(); }
        });
        
        </script>
        </head>
        <body class="container" style="width: 100%; padding-left: 5%; padding-right: 5%; padding-top: 1%;"><form autocomplete="off"><div class="row"><!-- START Element 1 Type: 19-->
        
        </div><div class="row">
        <script>orderOfTasks=getInt('orderofTasks');
taskT = 'II';
if (orderOfTasks== 3 || orderOfTasks== 4  ) {
    
    taskT='I';

} else if (orderOfTasks== 2  || orderOfTasks== 6  ){
    taskT='III';  

}

var counterI = getValue('counterI');
var counterII = getValue('counterII');
var counterIII = getValue('counterIII');
var period = getValue('period');
var whichOrder = orderOfTasks;</script><!-- END Element 1 Type: 19-->
        
        <!-- START Element 2 Type: 1-->
        
        </div><div class="row"><div id="wrap2" style="display: none;"><div class="btnbox2 paddlr" style="text-align: center"><h3>Round completed</h3>This is the end of round <script>document.write(counterII)</script>.&nbsp;<br><span style="background-color: initial;">Click below to continue.</span></div>
        </div><script>if((counterII < 30)) { $('#wrap2').show(); } </script><!-- END Element 2 Type: 1-->
        
        <!-- START Element 3 Type: 1-->
        
        </div><div class="row"><div id="wrap3" style="display: none;"><div class="btnbox2 paddlr" style="text-align: center"><h3>End of Task <script>document.write(taskT)</script></h3><p>You have completed this task. You will be able to see your earnings after you completed all three tasks and the questionnaires.<br>Click the button to proceed.</p></div>
        </div><script>if((counterII >=30 && (whichOrder == 1 || whichOrder == 3 || whichOrder == 4 || whichOrder == 5))) { $('#wrap3').show(); } </script><!-- END Element 3 Type: 1-->
        
        <!-- START Element 4 Type: 1-->
        
        </div><div class="row"><div id="wrap4" style="display: none;"><div class="btnbox2 paddlr" style="text-align: center"><h3>End of Task <script>document.write(taskT)</script>
</h3><p>You have now completed the last task. Click the button to proceed with the questionnaires.</p></div>
        </div><script>if((counterII >=30 && (whichOrder == 2 || whichOrder == 6))) { $('#wrap4').show(); } </script><!-- END Element 4 Type: 1-->
        
        <!-- START Element 5 Type: 18-->
        
        </div><div class="row"><div id="wrap5" style="display: none;">
        <script>
       
        
        </script>
        
        <div  id="button5">
        <div id="buttonclick5" class="btn btn-default btn-lg btn-block btn-info" style=" white-space:normal !important; word-wrap: break-word;" onclick="
        $(this).hide(); $('#buttonload5').show();
        if (additionalCheck5()) {
            hideError5();
            if (checkEntries()) toNextPage5();
            else  { $(this).show(); 
            $('#buttonload5').hide(); }
        } else {
         $(this).show(); 
         $('#buttonload5').hide();
         }
        ">Go to next Task</div><div id="buttonload5" style="width: 100%; text-align: center; display: none;"><img src="<?php echo PATH;?>basis/buttonload.gif"></div><div id="field5_error" class="alert alert-danger" style="display: none; text-align: center;"></div><div id="field5_attempts" class="alert alert-warning" style="display: none; text-align: center;"></div></div><script>if(maxFalse!=null) {
            var numFails=quizFail(playerNr,1);  
            $('#field5_attempts').html('Attempts left to answer the control questions: '+(maxFalse-numFails));
            $('#field5_attempts').show();
        
        }
        function showError5(text) {
            var errorfield= $('#field5_error');
            errorfield.show();
            errorfield.html(text);
        
        }
        
        function hideError5() {
            $('#field5_error').hide();
        }
       
        
        

        if (typeof window.showNext === 'undefined') {
            window.showNext = function(url, nextstage, stageNr) {
                var timeRecName = "time_" + stageNr;
                var timeOnThisPage = getServerTime() - tStart;
                setValue(timeRecName, timeOnThisPage);
                if (nextstage==popup) { myPopup(url);}
                else { location.replace(url); }
            }
        }


        

        var checker;
        
        function checkEntries() {
           checker=0;

            var numEntries = document.forms[0].length;
            var numValuesExpected=0;

            for (var i=0; i<numEntries; i++)
            {
                var name = "checkValue_" + document.forms[0][i].id;
                if (document.forms[0][i].id!="")
                {                   
                    window[name](); /* this is a generic function calling the checker for the variable "name"  */
                    ++numValuesExpected;
                 };

            }
           if (checker==numValuesExpected) return true;
           else {
                checkFail();
                return false;
            }
        }
        
        function additionalCheck5() {newPer = period+1;

setValue('core', 'playerNr='+playerNr, 'period', newPer);
insertRecord('decisions', 'playerNr,period,counterI,counterII,counterIII,orderofTasks',[playerNr,newPer,counterI,counterII,counterIII,whichOrder]);

           return true;
        }

       



        function checkFail() {} function toNextPage5() {
            if (loopEnd==32744) { showNext('wait32744.php?session_index=<?php echo $_SESSION[sessionID];?>',32727,32744);}
            else {showNext('stage32727.php?session_index=<?php echo $_SESSION[sessionID];?>',32727,32744);}

            };</script></div><script>if((counterII >=30 && (whichOrder == 4 || whichOrder == 5))) { $('#wrap5').show(); $('#buttonclick5').addClass('buttonclick');} </script><!-- END Element 5 Type: 18-->
        
        <!-- START Element 6 Type: 18-->
        
        </div><div class="row"><div id="wrap6" style="display: none;">
        <script>
       
        
        </script>
        
        <div  id="button6">
        <div id="buttonclick6" class="btn btn-default btn-lg btn-block " style=" white-space:normal !important; word-wrap: break-word;" onclick="
        $(this).hide(); $('#buttonload6').show();
        if (additionalCheck6()) {
            hideError6();
            if (checkEntries()) toNextPage6();
            else  { $(this).show(); 
            $('#buttonload6').hide(); }
        } else {
         $(this).show(); 
         $('#buttonload6').hide();
         }
        ">Continue</div><div id="buttonload6" style="width: 100%; text-align: center; display: none;"><img src="<?php echo PATH;?>basis/buttonload.gif"></div><div id="field6_error" class="alert alert-danger" style="display: none; text-align: center;"></div><div id="field6_attempts" class="alert alert-warning" style="display: none; text-align: center;"></div></div><script>if(maxFalse!=null) {
            var numFails=quizFail(playerNr,1);  
            $('#field6_attempts').html('Attempts left to answer the control questions: '+(maxFalse-numFails));
            $('#field6_attempts').show();
        
        }
        function showError6(text) {
            var errorfield= $('#field6_error');
            errorfield.show();
            errorfield.html(text);
        
        }
        
        function hideError6() {
            $('#field6_error').hide();
        }
       
        
        

        if (typeof window.showNext === 'undefined') {
            window.showNext = function(url, nextstage, stageNr) {
                var timeRecName = "time_" + stageNr;
                var timeOnThisPage = getServerTime() - tStart;
                setValue(timeRecName, timeOnThisPage);
                if (nextstage==popup) { myPopup(url);}
                else { location.replace(url); }
            }
        }


        

        var checker;
        
        function checkEntries() {
           checker=0;

            var numEntries = document.forms[0].length;
            var numValuesExpected=0;

            for (var i=0; i<numEntries; i++)
            {
                var name = "checkValue_" + document.forms[0][i].id;
                if (document.forms[0][i].id!="")
                {                   
                    window[name](); /* this is a generic function calling the checker for the variable "name"  */
                    ++numValuesExpected;
                 };

            }
           if (checker==numValuesExpected) return true;
           else {
                checkFail();
                return false;
            }
        }
        
        function additionalCheck6() {newPer = period+1;
newCounter = counterII+1;

setValue('core', 'playerNr='+playerNr, 'period', newPer);
insertRecord('decisions', 'playerNr,period,counterI,counterII,counterIII,orderofTasks',[playerNr,newPer,counterI,newCounter,counterIII,whichOrder]);

           return true;
        }

       



        function checkFail() {} function toNextPage6() {
            if (loopEnd==32744) { showNext('wait32744.php?session_index=<?php echo $_SESSION[sessionID];?>',32740,32744);}
            else {showNext('stage32740.php?session_index=<?php echo $_SESSION[sessionID];?>',32740,32744);}

            };</script></div><script>if((counterII <30)) { $('#wrap6').show(); $('#buttonclick6').addClass('buttonclick');} </script><!-- END Element 6 Type: 18-->
        
        <!-- START Element 7 Type: 18-->
        
        </div><div class="row"><div id="wrap7" style="display: none;">
        <script>
       
        
        </script>
        
        <div  id="button7">
        <div id="buttonclick7" class="btn btn-default btn-lg btn-block btn-info" style=" white-space:normal !important; word-wrap: break-word;" onclick="
        $(this).hide(); $('#buttonload7').show();
        if (additionalCheck7()) {
            hideError7();
            if (checkEntries()) toNextPage7();
            else  { $(this).show(); 
            $('#buttonload7').hide(); }
        } else {
         $(this).show(); 
         $('#buttonload7').hide();
         }
        ">Go to next Task</div><div id="buttonload7" style="width: 100%; text-align: center; display: none;"><img src="<?php echo PATH;?>basis/buttonload.gif"></div><div id="field7_error" class="alert alert-danger" style="display: none; text-align: center;"></div><div id="field7_attempts" class="alert alert-warning" style="display: none; text-align: center;"></div></div><script>if(maxFalse!=null) {
            var numFails=quizFail(playerNr,1);  
            $('#field7_attempts').html('Attempts left to answer the control questions: '+(maxFalse-numFails));
            $('#field7_attempts').show();
        
        }
        function showError7(text) {
            var errorfield= $('#field7_error');
            errorfield.show();
            errorfield.html(text);
        
        }
        
        function hideError7() {
            $('#field7_error').hide();
        }
       
        
        

        if (typeof window.showNext === 'undefined') {
            window.showNext = function(url, nextstage, stageNr) {
                var timeRecName = "time_" + stageNr;
                var timeOnThisPage = getServerTime() - tStart;
                setValue(timeRecName, timeOnThisPage);
                if (nextstage==popup) { myPopup(url);}
                else { location.replace(url); }
            }
        }


        

        var checker;
        
        function checkEntries() {
           checker=0;

            var numEntries = document.forms[0].length;
            var numValuesExpected=0;

            for (var i=0; i<numEntries; i++)
            {
                var name = "checkValue_" + document.forms[0][i].id;
                if (document.forms[0][i].id!="")
                {                   
                    window[name](); /* this is a generic function calling the checker for the variable "name"  */
                    ++numValuesExpected;
                 };

            }
           if (checker==numValuesExpected) return true;
           else {
                checkFail();
                return false;
            }
        }
        
        function additionalCheck7() {newPer = period+1;

setValue('core', 'playerNr='+playerNr, 'period', newPer);
insertRecord('decisions', 'playerNr,period,counterI,counterII,counterIII,orderofTasks',[playerNr,newPer,counterI,counterII,counterIII,whichOrder]);

           return true;
        }

       



        function checkFail() {} function toNextPage7() {
            if (loopEnd==32744) { showNext('wait32744.php?session_index=<?php echo $_SESSION[sessionID];?>',32745,32744);}
            else {showNext('stage32745.php?session_index=<?php echo $_SESSION[sessionID];?>',32745,32744);}

            };</script></div><script>if((counterII >=30 && (whichOrder == 1 || whichOrder == 3))) { $('#wrap7').show(); $('#buttonclick7').addClass('buttonclick');} </script><!-- END Element 7 Type: 18-->
        
        <!-- START Element 8 Type: 18-->
        
        </div><div class="row"><div id="wrap8" style="display: none;">
        <script>
       
        
        </script>
        
        <div  id="button8">
        <div id="buttonclick8" class="btn btn-default btn-lg btn-block btn-success" style=" white-space:normal !important; word-wrap: break-word;" onclick="
        $(this).hide(); $('#buttonload8').show();
        if (additionalCheck8()) {
            hideError8();
            if (checkEntries()) toNextPage8();
            else  { $(this).show(); 
            $('#buttonload8').hide(); }
        } else {
         $(this).show(); 
         $('#buttonload8').hide();
         }
        ">Go to questionnaire</div><div id="buttonload8" style="width: 100%; text-align: center; display: none;"><img src="<?php echo PATH;?>basis/buttonload.gif"></div><div id="field8_error" class="alert alert-danger" style="display: none; text-align: center;"></div><div id="field8_attempts" class="alert alert-warning" style="display: none; text-align: center;"></div></div><script>if(maxFalse!=null) {
            var numFails=quizFail(playerNr,1);  
            $('#field8_attempts').html('Attempts left to answer the control questions: '+(maxFalse-numFails));
            $('#field8_attempts').show();
        
        }
        function showError8(text) {
            var errorfield= $('#field8_error');
            errorfield.show();
            errorfield.html(text);
        
        }
        
        function hideError8() {
            $('#field8_error').hide();
        }
       
        
        

        if (typeof window.showNext === 'undefined') {
            window.showNext = function(url, nextstage, stageNr) {
                var timeRecName = "time_" + stageNr;
                var timeOnThisPage = getServerTime() - tStart;
                setValue(timeRecName, timeOnThisPage);
                if (nextstage==popup) { myPopup(url);}
                else { location.replace(url); }
            }
        }


        

        var checker;
        
        function checkEntries() {
           checker=0;

            var numEntries = document.forms[0].length;
            var numValuesExpected=0;

            for (var i=0; i<numEntries; i++)
            {
                var name = "checkValue_" + document.forms[0][i].id;
                if (document.forms[0][i].id!="")
                {                   
                    window[name](); /* this is a generic function calling the checker for the variable "name"  */
                    ++numValuesExpected;
                 };

            }
           if (checker==numValuesExpected) return true;
           else {
                checkFail();
                return false;
            }
        }
        
        function additionalCheck8() {

           return true;
        }

       



        function checkFail() {} function toNextPage8() {
            if (loopEnd==32744) { showNext('wait32744.php?session_index=<?php echo $_SESSION[sessionID];?>',32753,32744);}
            else {showNext('stage32753.php?session_index=<?php echo $_SESSION[sessionID];?>',32753,32744);}

            };</script></div><script>if((counterII >=30 && (whichOrder == 2 || whichOrder == 6))) { $('#wrap8').show(); $('#buttonclick8').addClass('buttonclick');} </script><!-- END Element 8 Type: 18-->
        
        </div><script>setInterval(function(){ if (counterII < 30) $('#wrap2').show();if (!(counterII < 30)) $('#wrap2').hide();if (counterII >=30 && (whichOrder == 1 || whichOrder == 3 || whichOrder == 4 || whichOrder == 5)) $('#wrap3').show();if (!(counterII >=30 && (whichOrder == 1 || whichOrder == 3 || whichOrder == 4 || whichOrder == 5))) $('#wrap3').hide();if (counterII >=30 && (whichOrder == 2 || whichOrder == 6)) $('#wrap4').show();if (!(counterII >=30 && (whichOrder == 2 || whichOrder == 6))) $('#wrap4').hide();if (counterII >=30 && (whichOrder == 4 || whichOrder == 5)) $('#wrap5').show();if (!(counterII >=30 && (whichOrder == 4 || whichOrder == 5))) $('#wrap5').hide();if (counterII <30) $('#wrap6').show();if (!(counterII <30)) $('#wrap6').hide();if (counterII >=30 && (whichOrder == 1 || whichOrder == 3)) $('#wrap7').show();if (!(counterII >=30 && (whichOrder == 1 || whichOrder == 3))) $('#wrap7').hide();if (counterII >=30 && (whichOrder == 2 || whichOrder == 6)) $('#wrap8').show();if (!(counterII >=30 && (whichOrder == 2 || whichOrder == 6))) $('#wrap8').hide(); }, 100);</script></form></div></body></html>