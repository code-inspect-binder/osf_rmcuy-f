<html>
        <head>
        <?php
  
        include("_projectID.php");
        session_start();
	    $_SESSION['projectID']=PROJECTID;
	    include(PATH."basis/LIONESS.php");
	    ?>

        <link href="<?php echo PATH;?>basis/newlayout.css" rel="stylesheet" type="text/css"  />
        <link href="<?php echo PATH;?>basis/newlayout_bootstrap.css" rel="stylesheet" type="text/css"  />
        <link href="<?php echo PATH;?>basis/grid.css" rel="stylesheet" type="text/css"  /><title>questionnaire 4</title>

        <script> var v={}; var wronganswers={};var maxFalse = null;
        var firstStageExp = <?php echo json_encode(FIRSTPAGE . ".php"); ?>;
        var thisPage = <?php echo json_encode($thisPage); ?>;
      
        pageRefreshed=0;
        var loopBegin = "stage" + loopStart + ".php";
        var afterLoopEnd = 32755;
        if (thisPage == firstStageExp || (thisPage==loopBegin && period > 1) || loopEnd==afterLoopEnd) firstStage();
        /* if (thisPage == firstStageExp || thisPage==loopBegin || loopEnd==afterLoopEnd) firstStage(); */
        TimeOut=null;
        function skipStage() {
         location.replace('wait32756.php?session_index=<?php echo $_SESSION[sessionID];?>');
        }
        $(document).ready(function(){
        if (bot) { document.getElementsByClassName("buttonclick")[0].click(); }
        });
        
        </script>
        </head>
        <body class="container" style="width: 100%; padding-left: 5%; padding-right: 5%; padding-top: 1%;"><form autocomplete="off"><div class="row"><!-- START Element 1 Type: 19-->
        
        </div><div class="row">
        <script></script><!-- END Element 1 Type: 19-->
        
        <!-- START Element 2 Type: 1-->
        
        </div><div class="row"><div id="wrap2" style="display: none;"><div class="btnbox2 paddlr" style="text-align: center"><h3>Questionnaire 4 of 5
</h3><p>Below, you find a list with 10 pairs of statements. <br>For each pair, please indicate which one describes you best.</p><p></p></div>
        </div><script>if((true)) { $('#wrap2').show(); } </script><!-- END Element 2 Type: 1-->
        
        <!-- START Element 3 Type: 21-->
        
        </div><div class="row"><div id="wrap3" style="display: none;"><div class="btnbox2"><div class="form-group"><label></label><table class="table"
         rules="none" style="margin-left:auto;margin-right:auto;"><tr><td style="padding: 10px; text-align: right; font-size: small;vertical-align: bottom;">1. I go along with my friends just to keep them happy.</td><td style="text-align: center;"><label class="checkbox-inline"><input  type="radio" name="3" id="field3" value="1"

            onclick="resistance_peer_influence_1=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="3" id="field3" value="2"

            onclick="resistance_peer_influence_1=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="3" id="field3" value="3"

            onclick="resistance_peer_influence_1=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="3" id="field3" value="4"

            onclick="resistance_peer_influence_1=this.value;"
            ></label><td style="padding: 10px; text-align: left;font-size: small; vertical-align: bottom; " >I refuse to go along with what my friends want to do, even though I know it will make them unhappy.</td></tr></table></div><div id="field3_noEntry" class="messagefield3 alert alert-danger" style="display: none;">Please indicate your response </div><div id="field3_notcorrect" class="messagefield3 alert alert-danger" style="display: none;">The value you entered is not correct.</div></div><script>var resistance_peer_influence_1=null;            

                  var k=0;

                  function checkValue_field3() {
                 var label="resistance_peer_influence_1";var min=1;var max=4;var labelleft="1. I go along with my friends just to keep them happy.";var labelright="I refuse to go along with what my friends want to do, even though I know it will make them unhappy.";var required=1;var correct=null;if(!(true)) {
                  checker=checker+1;
                } else {
                    k++;
                     if (bot) { 
                       if (correct != null) { value = correct; }
                        else if (typeof bot_resistance_peer_influence_1 !== 'undefined') { value=bot_resistance_peer_influence_1; }
                        else { value=Math.floor(Math.random()*max)+min; }
                    }
                    else { value=$("input[name=3]:checked").val(); }
                    
                    $('.messagefield3').hide();
                       allcorrect=checker+1;
                      /* check if any entry has been made */
                      if ((isNaN(value) || value == "") && required==1) {
                          $('#field3_noEntry').show();
                      }
                      else if (value!=correct && correct != null && required!=0) {
                            $('#field3_notcorrect').show();
                        } 
                      else {
                          
           
                                 record("resistance_peer_influence_1", value);
                                 checker = checker+1;
                             }
                             
                             if (allcorrect!=checker) {
                      wronganswers['resistance_peer_influence_1']=1;
                   } else wronganswers['resistance_peer_influence_1']=0;    
                         }
                    
                    
                }
              </script></div></div></div><script>if((true)) { $('#wrap3').show(); } </script><!-- END Element 3 Type: 21-->
        
        <!-- START Element 4 Type: 21-->
        
        </div><div class="row"><div id="wrap4" style="display: none;"><div class="btnbox2"><div class="form-group"><label></label><table class="table"
         rules="none" style="margin-left:auto;margin-right:auto;"><tr><td style="padding: 10px; text-align: right; font-size: small;vertical-align: bottom;">2. I think it’s more important to be an individual than to fit in with the crowd.</td><td style="text-align: center;"><label class="checkbox-inline"><input  type="radio" name="4" id="field4" value="1"

            onclick="resistance_peer_influence_2=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="4" id="field4" value="2"

            onclick="resistance_peer_influence_2=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="4" id="field4" value="3"

            onclick="resistance_peer_influence_2=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="4" id="field4" value="4"

            onclick="resistance_peer_influence_2=this.value;"
            ></label><td style="padding: 10px; text-align: left;font-size: small; vertical-align: bottom; " >I think it is more important to fit in with the crowd than to stand out as an individual.</td></tr></table></div><div id="field4_noEntry" class="messagefield4 alert alert-danger" style="display: none;">Please indicate your response </div><div id="field4_notcorrect" class="messagefield4 alert alert-danger" style="display: none;">The value you entered is not correct.</div></div><script>var resistance_peer_influence_2=null;            

                  var k=0;

                  function checkValue_field4() {
                 var label="resistance_peer_influence_2";var min=1;var max=4;var labelleft="2. I think it\u2019s more important to be an individual than to fit in with the crowd.";var labelright="I think it is more important to fit in with the crowd than to stand out as an individual.";var required=1;var correct=null;if(!(true)) {
                  checker=checker+1;
                } else {
                    k++;
                     if (bot) { 
                       if (correct != null) { value = correct; }
                        else if (typeof bot_resistance_peer_influence_2 !== 'undefined') { value=bot_resistance_peer_influence_2; }
                        else { value=Math.floor(Math.random()*max)+min; }
                    }
                    else { value=$("input[name=4]:checked").val(); }
                    
                    $('.messagefield4').hide();
                       allcorrect=checker+1;
                      /* check if any entry has been made */
                      if ((isNaN(value) || value == "") && required==1) {
                          $('#field4_noEntry').show();
                      }
                      else if (value!=correct && correct != null && required!=0) {
                            $('#field4_notcorrect').show();
                        } 
                      else {
                          
           
                                 record("resistance_peer_influence_2", value);
                                 checker = checker+1;
                             }
                             
                             if (allcorrect!=checker) {
                      wronganswers['resistance_peer_influence_2']=1;
                   } else wronganswers['resistance_peer_influence_2']=0;    
                         }
                    
                    
                }
              </script></div></div></div><script>if((true)) { $('#wrap4').show(); } </script><!-- END Element 4 Type: 21-->
        
        <!-- START Element 5 Type: 21-->
        
        </div><div class="row"><div id="wrap5" style="display: none;"><div class="btnbox2"><div class="form-group"><label></label><table class="table"
         rules="none" style="margin-left:auto;margin-right:auto;"><tr><td style="padding: 10px; text-align: right; font-size: small;vertical-align: bottom;">3. It’s pretty easy for my friends to get me to change my mind</td><td style="text-align: center;"><label class="checkbox-inline"><input  type="radio" name="5" id="field5" value="1"

            onclick="resistance_peer_influence_3=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="5" id="field5" value="2"

            onclick="resistance_peer_influence_3=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="5" id="field5" value="3"

            onclick="resistance_peer_influence_3=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="5" id="field5" value="4"

            onclick="resistance_peer_influence_3=this.value;"
            ></label><td style="padding: 10px; text-align: left;font-size: small; vertical-align: bottom; " >It’s pretty hard for my friends to get them to change my mind.</td></tr></table></div><div id="field5_noEntry" class="messagefield5 alert alert-danger" style="display: none;">Please indicate your response </div><div id="field5_notcorrect" class="messagefield5 alert alert-danger" style="display: none;">The value you entered is not correct.</div></div><script>var resistance_peer_influence_3=null;            

                  var k=0;

                  function checkValue_field5() {
                 var label="resistance_peer_influence_3";var min=1;var max=4;var labelleft="3. It\u2019s pretty easy for my friends to get me to change my mind";var labelright="It\u2019s pretty hard for my friends to get them to change my mind.";var required=1;var correct=null;if(!(true)) {
                  checker=checker+1;
                } else {
                    k++;
                     if (bot) { 
                       if (correct != null) { value = correct; }
                        else if (typeof bot_resistance_peer_influence_3 !== 'undefined') { value=bot_resistance_peer_influence_3; }
                        else { value=Math.floor(Math.random()*max)+min; }
                    }
                    else { value=$("input[name=5]:checked").val(); }
                    
                    $('.messagefield5').hide();
                       allcorrect=checker+1;
                      /* check if any entry has been made */
                      if ((isNaN(value) || value == "") && required==1) {
                          $('#field5_noEntry').show();
                      }
                      else if (value!=correct && correct != null && required!=0) {
                            $('#field5_notcorrect').show();
                        } 
                      else {
                          
           
                                 record("resistance_peer_influence_3", value);
                                 checker = checker+1;
                             }
                             
                             if (allcorrect!=checker) {
                      wronganswers['resistance_peer_influence_3']=1;
                   } else wronganswers['resistance_peer_influence_3']=0;    
                         }
                    
                    
                }
              </script></div></div></div><script>if((true)) { $('#wrap5').show(); } </script><!-- END Element 5 Type: 21-->
        
        <!-- START Element 6 Type: 21-->
        
        </div><div class="row"><div id="wrap6" style="display: none;"><div class="btnbox2"><div class="form-group"><label></label><table class="table"
         rules="none" style="margin-left:auto;margin-right:auto;"><tr><td style="padding: 10px; text-align: right; font-size: small;vertical-align: bottom;">4. I would do something that I know is wrong just to stay on my friends’ good side.</td><td style="text-align: center;"><label class="checkbox-inline"><input  type="radio" name="6" id="field6" value="1"

            onclick="resistance_peer_influence_4=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="6" id="field6" value="2"

            onclick="resistance_peer_influence_4=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="6" id="field6" value="3"

            onclick="resistance_peer_influence_4=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="6" id="field6" value="4"

            onclick="resistance_peer_influence_4=this.value;"
            ></label><td style="padding: 10px; text-align: left;font-size: small; vertical-align: bottom; " >I would not do something I knew was wrong just to stay on my friends’ good side.</td></tr></table></div><div id="field6_noEntry" class="messagefield6 alert alert-danger" style="display: none;">Please indicate your response </div><div id="field6_notcorrect" class="messagefield6 alert alert-danger" style="display: none;">The value you entered is not correct.</div></div><script>var resistance_peer_influence_4=null;            

                  var k=0;

                  function checkValue_field6() {
                 var label="resistance_peer_influence_4";var min=1;var max=4;var labelleft="4. I would do something that I know is wrong just to stay on my friends\u2019 good side.";var labelright="I would not do something I knew was wrong just to stay on my friends\u2019 good side.";var required=1;var correct=null;if(!(true)) {
                  checker=checker+1;
                } else {
                    k++;
                     if (bot) { 
                       if (correct != null) { value = correct; }
                        else if (typeof bot_resistance_peer_influence_4 !== 'undefined') { value=bot_resistance_peer_influence_4; }
                        else { value=Math.floor(Math.random()*max)+min; }
                    }
                    else { value=$("input[name=6]:checked").val(); }
                    
                    $('.messagefield6').hide();
                       allcorrect=checker+1;
                      /* check if any entry has been made */
                      if ((isNaN(value) || value == "") && required==1) {
                          $('#field6_noEntry').show();
                      }
                      else if (value!=correct && correct != null && required!=0) {
                            $('#field6_notcorrect').show();
                        } 
                      else {
                          
           
                                 record("resistance_peer_influence_4", value);
                                 checker = checker+1;
                             }
                             
                             if (allcorrect!=checker) {
                      wronganswers['resistance_peer_influence_4']=1;
                   } else wronganswers['resistance_peer_influence_4']=0;    
                         }
                    
                    
                }
              </script></div></div></div><script>if((true)) { $('#wrap6').show(); } </script><!-- END Element 6 Type: 21-->
        
        <!-- START Element 7 Type: 21-->
        
        </div><div class="row"><div id="wrap7" style="display: none;"><div class="btnbox2"><div class="form-group"><label></label><table class="table"
         rules="none" style="margin-left:auto;margin-right:auto;"><tr><td style="padding: 10px; text-align: right; font-size: small;vertical-align: bottom;">5. I hide my true opinion from my friends if I think my friends will make fun of me because of it.</td><td style="text-align: center;"><label class="checkbox-inline"><input  type="radio" name="7" id="field7" value="1"

            onclick="resistance_peer_influence_5=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="7" id="field7" value="2"

            onclick="resistance_peer_influence_5=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="7" id="field7" value="3"

            onclick="resistance_peer_influence_5=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="7" id="field7" value="4"

            onclick="resistance_peer_influence_5=this.value;"
            ></label><td style="padding: 10px; text-align: left;font-size: small; vertical-align: bottom; " >I will say my true opinion in front of my friends, even if I know my friends will make fun of me because of it.</td></tr></table></div><div id="field7_noEntry" class="messagefield7 alert alert-danger" style="display: none;">Please indicate your response </div><div id="field7_notcorrect" class="messagefield7 alert alert-danger" style="display: none;">The value you entered is not correct.</div></div><script>var resistance_peer_influence_5=null;            

                  var k=0;

                  function checkValue_field7() {
                 var label="resistance_peer_influence_5";var min=1;var max=4;var labelleft="5. I hide my true opinion from my friends if I think my friends will make fun of me because of it.";var labelright="I will say my true opinion in front of my friends, even if I know my friends will make fun of me because of it.";var required=1;var correct=null;if(!(true)) {
                  checker=checker+1;
                } else {
                    k++;
                     if (bot) { 
                       if (correct != null) { value = correct; }
                        else if (typeof bot_resistance_peer_influence_5 !== 'undefined') { value=bot_resistance_peer_influence_5; }
                        else { value=Math.floor(Math.random()*max)+min; }
                    }
                    else { value=$("input[name=7]:checked").val(); }
                    
                    $('.messagefield7').hide();
                       allcorrect=checker+1;
                      /* check if any entry has been made */
                      if ((isNaN(value) || value == "") && required==1) {
                          $('#field7_noEntry').show();
                      }
                      else if (value!=correct && correct != null && required!=0) {
                            $('#field7_notcorrect').show();
                        } 
                      else {
                          
           
                                 record("resistance_peer_influence_5", value);
                                 checker = checker+1;
                             }
                             
                             if (allcorrect!=checker) {
                      wronganswers['resistance_peer_influence_5']=1;
                   } else wronganswers['resistance_peer_influence_5']=0;    
                         }
                    
                    
                }
              </script></div></div></div><script>if((true)) { $('#wrap7').show(); } </script><!-- END Element 7 Type: 21-->
        
        <!-- START Element 8 Type: 21-->
        
        </div><div class="row"><div id="wrap8" style="display: none;"><div class="btnbox2"><div class="form-group"><label></label><table class="table"
         rules="none" style="margin-left:auto;margin-right:auto;"><tr><td style="padding: 10px; text-align: right; font-size: small;vertical-align: bottom;">6. I will not break the law just because my friends say that they would.</td><td style="text-align: center;"><label class="checkbox-inline"><input  type="radio" name="8" id="field8" value="1"

            onclick="resistance_peer_influence_6=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="8" id="field8" value="2"

            onclick="resistance_peer_influence_6=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="8" id="field8" value="3"

            onclick="resistance_peer_influence_6=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="8" id="field8" value="4"

            onclick="resistance_peer_influence_6=this.value;"
            ></label><td style="padding: 10px; text-align: left;font-size: small; vertical-align: bottom; " >I would break the law if my friends said that they would break it.</td></tr></table></div><div id="field8_noEntry" class="messagefield8 alert alert-danger" style="display: none;">Please indicate your response </div><div id="field8_notcorrect" class="messagefield8 alert alert-danger" style="display: none;">The value you entered is not correct.</div></div><script>var resistance_peer_influence_6=null;            

                  var k=0;

                  function checkValue_field8() {
                 var label="resistance_peer_influence_6";var min=1;var max=4;var labelleft="6. I will not break the law just because my friends say that they would.";var labelright="I would break the law if my friends said that they would break it.";var required=1;var correct=null;if(!(true)) {
                  checker=checker+1;
                } else {
                    k++;
                     if (bot) { 
                       if (correct != null) { value = correct; }
                        else if (typeof bot_resistance_peer_influence_6 !== 'undefined') { value=bot_resistance_peer_influence_6; }
                        else { value=Math.floor(Math.random()*max)+min; }
                    }
                    else { value=$("input[name=8]:checked").val(); }
                    
                    $('.messagefield8').hide();
                       allcorrect=checker+1;
                      /* check if any entry has been made */
                      if ((isNaN(value) || value == "") && required==1) {
                          $('#field8_noEntry').show();
                      }
                      else if (value!=correct && correct != null && required!=0) {
                            $('#field8_notcorrect').show();
                        } 
                      else {
                          
           
                                 record("resistance_peer_influence_6", value);
                                 checker = checker+1;
                             }
                             
                             if (allcorrect!=checker) {
                      wronganswers['resistance_peer_influence_6']=1;
                   } else wronganswers['resistance_peer_influence_6']=0;    
                         }
                    
                    
                }
              </script></div></div></div><script>if((true)) { $('#wrap8').show(); } </script><!-- END Element 8 Type: 21-->
        
        <!-- START Element 9 Type: 21-->
        
        </div><div class="row"><div id="wrap9" style="display: none;"><div class="btnbox2"><div class="form-group"><label></label><table class="table"
         rules="none" style="margin-left:auto;margin-right:auto;"><tr><td style="padding: 10px; text-align: right; font-size: small;vertical-align: bottom;">7. I change the way I act so much when I am with my friends that I wonder who I “really am”.</td><td style="text-align: center;"><label class="checkbox-inline"><input  type="radio" name="9" id="field9" value="1"

            onclick="resistance_peer_influence_7=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="9" id="field9" value="2"

            onclick="resistance_peer_influence_7=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="9" id="field9" value="3"

            onclick="resistance_peer_influence_7=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="9" id="field9" value="4"

            onclick="resistance_peer_influence_7=this.value;"
            ></label><td style="padding: 10px; text-align: left;font-size: small; vertical-align: bottom; " >I act the same way when I am alone as I do when I am with my friends.</td></tr></table></div><div id="field9_noEntry" class="messagefield9 alert alert-danger" style="display: none;">Please indicate your response </div><div id="field9_notcorrect" class="messagefield9 alert alert-danger" style="display: none;">The value you entered is not correct.</div></div><script>var resistance_peer_influence_7=null;            

                  var k=0;

                  function checkValue_field9() {
                 var label="resistance_peer_influence_7";var min=1;var max=4;var labelleft="7. I change the way I act so much when I am with my friends that I wonder who I \u201creally am\u201d.";var labelright="I act the same way when I am alone as I do when I am with my friends.";var required=1;var correct=null;if(!(true)) {
                  checker=checker+1;
                } else {
                    k++;
                     if (bot) { 
                       if (correct != null) { value = correct; }
                        else if (typeof bot_resistance_peer_influence_7 !== 'undefined') { value=bot_resistance_peer_influence_7; }
                        else { value=Math.floor(Math.random()*max)+min; }
                    }
                    else { value=$("input[name=9]:checked").val(); }
                    
                    $('.messagefield9').hide();
                       allcorrect=checker+1;
                      /* check if any entry has been made */
                      if ((isNaN(value) || value == "") && required==1) {
                          $('#field9_noEntry').show();
                      }
                      else if (value!=correct && correct != null && required!=0) {
                            $('#field9_notcorrect').show();
                        } 
                      else {
                          
           
                                 record("resistance_peer_influence_7", value);
                                 checker = checker+1;
                             }
                             
                             if (allcorrect!=checker) {
                      wronganswers['resistance_peer_influence_7']=1;
                   } else wronganswers['resistance_peer_influence_7']=0;    
                         }
                    
                    
                }
              </script></div></div></div><script>if((true)) { $('#wrap9').show(); } </script><!-- END Element 9 Type: 21-->
        
        <!-- START Element 10 Type: 21-->
        
        </div><div class="row"><div id="wrap10" style="display: none;"><div class="btnbox2"><div class="form-group"><label></label><table class="table"
         rules="none" style="margin-left:auto;margin-right:auto;"><tr><td style="padding: 10px; text-align: right; font-size: small;vertical-align: bottom;">8. I take more risks when I am with my friends than I do when I am alone.</td><td style="text-align: center;"><label class="checkbox-inline"><input  type="radio" name="10" id="field10" value="1"

            onclick="resistance_peer_influence_8=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="10" id="field10" value="2"

            onclick="resistance_peer_influence_8=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="10" id="field10" value="3"

            onclick="resistance_peer_influence_8=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="10" id="field10" value="4"

            onclick="resistance_peer_influence_8=this.value;"
            ></label><td style="padding: 10px; text-align: left;font-size: small; vertical-align: bottom; " >I act just as risky when I am alone as when I am with my friends.</td></tr></table></div><div id="field10_noEntry" class="messagefield10 alert alert-danger" style="display: none;">Please indicate your response </div><div id="field10_notcorrect" class="messagefield10 alert alert-danger" style="display: none;">The value you entered is not correct.</div></div><script>var resistance_peer_influence_8=null;            

                  var k=0;

                  function checkValue_field10() {
                 var label="resistance_peer_influence_8";var min=1;var max=4;var labelleft="8. I take more risks when I am with my friends than I do when I am alone.";var labelright="I act just as risky when I am alone as when I am with my friends.";var required=1;var correct=null;if(!(true)) {
                  checker=checker+1;
                } else {
                    k++;
                     if (bot) { 
                       if (correct != null) { value = correct; }
                        else if (typeof bot_resistance_peer_influence_8 !== 'undefined') { value=bot_resistance_peer_influence_8; }
                        else { value=Math.floor(Math.random()*max)+min; }
                    }
                    else { value=$("input[name=10]:checked").val(); }
                    
                    $('.messagefield10').hide();
                       allcorrect=checker+1;
                      /* check if any entry has been made */
                      if ((isNaN(value) || value == "") && required==1) {
                          $('#field10_noEntry').show();
                      }
                      else if (value!=correct && correct != null && required!=0) {
                            $('#field10_notcorrect').show();
                        } 
                      else {
                          
           
                                 record("resistance_peer_influence_8", value);
                                 checker = checker+1;
                             }
                             
                             if (allcorrect!=checker) {
                      wronganswers['resistance_peer_influence_8']=1;
                   } else wronganswers['resistance_peer_influence_8']=0;    
                         }
                    
                    
                }
              </script></div></div></div><script>if((true)) { $('#wrap10').show(); } </script><!-- END Element 10 Type: 21-->
        
        <!-- START Element 11 Type: 21-->
        
        </div><div class="row"><div id="wrap11" style="display: none;"><div class="btnbox2"><div class="form-group"><label></label><table class="table"
         rules="none" style="margin-left:auto;margin-right:auto;"><tr><td style="padding: 10px; text-align: right; font-size: small;vertical-align: bottom;">9. I say things I don’t really believe because I think it will make my friends respect me more.</td><td style="text-align: center;"><label class="checkbox-inline"><input  type="radio" name="11" id="field11" value="1"

            onclick="resistance_peer_influence_9=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="11" id="field11" value="2"

            onclick="resistance_peer_influence_9=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="11" id="field11" value="3"

            onclick="resistance_peer_influence_9=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="11" id="field11" value="4"

            onclick="resistance_peer_influence_9=this.value;"
            ></label><td style="padding: 10px; text-align: left;font-size: small; vertical-align: bottom; " >I would not say things I didn’t really believe just to get my friends to respect me more.</td></tr></table></div><div id="field11_noEntry" class="messagefield11 alert alert-danger" style="display: none;">Please indicate your response </div><div id="field11_notcorrect" class="messagefield11 alert alert-danger" style="display: none;">The value you entered is not correct.</div></div><script>var resistance_peer_influence_9=null;            

                  var k=0;

                  function checkValue_field11() {
                 var label="resistance_peer_influence_9";var min=1;var max=4;var labelleft="9. I say things I don\u2019t really believe because I think it will make my friends respect me more.";var labelright="I would not say things I didn\u2019t really believe just to get my friends to respect me more.";var required=1;var correct=null;if(!(true)) {
                  checker=checker+1;
                } else {
                    k++;
                     if (bot) { 
                       if (correct != null) { value = correct; }
                        else if (typeof bot_resistance_peer_influence_9 !== 'undefined') { value=bot_resistance_peer_influence_9; }
                        else { value=Math.floor(Math.random()*max)+min; }
                    }
                    else { value=$("input[name=11]:checked").val(); }
                    
                    $('.messagefield11').hide();
                       allcorrect=checker+1;
                      /* check if any entry has been made */
                      if ((isNaN(value) || value == "") && required==1) {
                          $('#field11_noEntry').show();
                      }
                      else if (value!=correct && correct != null && required!=0) {
                            $('#field11_notcorrect').show();
                        } 
                      else {
                          
           
                                 record("resistance_peer_influence_9", value);
                                 checker = checker+1;
                             }
                             
                             if (allcorrect!=checker) {
                      wronganswers['resistance_peer_influence_9']=1;
                   } else wronganswers['resistance_peer_influence_9']=0;    
                         }
                    
                    
                }
              </script></div></div></div><script>if((true)) { $('#wrap11').show(); } </script><!-- END Element 11 Type: 21-->
        
        <!-- START Element 12 Type: 21-->
        
        </div><div class="row"><div id="wrap12" style="display: none;"><div class="btnbox2"><div class="form-group"><label></label><table class="table"
         rules="none" style="margin-left:auto;margin-right:auto;"><tr><td style="padding: 10px; text-align: right; font-size: small;vertical-align: bottom;">10. I think it’s better to be an individual even if people will be angry at you for going against the crowd.</td><td style="text-align: center;"><label class="checkbox-inline"><input  type="radio" name="12" id="field12" value="1"

            onclick="resistance_peer_influence_10=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="12" id="field12" value="2"

            onclick="resistance_peer_influence_10=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="12" id="field12" value="3"

            onclick="resistance_peer_influence_10=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="12" id="field12" value="4"

            onclick="resistance_peer_influence_10=this.value;"
            ></label><td style="padding: 10px; text-align: left;font-size: small; vertical-align: bottom; " >I think it’s better to go along with the crowd than to make people angry at you.</td></tr></table></div><div id="field12_noEntry" class="messagefield12 alert alert-danger" style="display: none;">Please indicate your response </div><div id="field12_notcorrect" class="messagefield12 alert alert-danger" style="display: none;">The value you entered is not correct.</div></div><script>var resistance_peer_influence_10=null;            

                  var k=0;

                  function checkValue_field12() {
                 var label="resistance_peer_influence_10";var min=1;var max=4;var labelleft="10. I think it\u2019s better to be an individual even if people will be angry at you for going against the crowd.";var labelright="I think it\u2019s better to go along with the crowd than to make people angry at you.";var required=1;var correct=null;if(!(true)) {
                  checker=checker+1;
                } else {
                    k++;
                     if (bot) { 
                       if (correct != null) { value = correct; }
                        else if (typeof bot_resistance_peer_influence_10 !== 'undefined') { value=bot_resistance_peer_influence_10; }
                        else { value=Math.floor(Math.random()*max)+min; }
                    }
                    else { value=$("input[name=12]:checked").val(); }
                    
                    $('.messagefield12').hide();
                       allcorrect=checker+1;
                      /* check if any entry has been made */
                      if ((isNaN(value) || value == "") && required==1) {
                          $('#field12_noEntry').show();
                      }
                      else if (value!=correct && correct != null && required!=0) {
                            $('#field12_notcorrect').show();
                        } 
                      else {
                          
           
                                 record("resistance_peer_influence_10", value);
                                 checker = checker+1;
                             }
                             
                             if (allcorrect!=checker) {
                      wronganswers['resistance_peer_influence_10']=1;
                   } else wronganswers['resistance_peer_influence_10']=0;    
                         }
                    
                    
                }
              </script></div></div></div><script>if((true)) { $('#wrap12').show(); } </script><!-- END Element 12 Type: 21-->
        
        <!-- START Element 13 Type: 18-->
        
        </div><div class="row"><div id="wrap13" style="display: none;">
        <script>
       
        
        </script>
        
        <div  id="button13">
        <div id="buttonclick13" class="btn btn-default btn-lg btn-block " style=" white-space:normal !important; word-wrap: break-word;" onclick="
        $(this).hide(); $('#buttonload13').show();
        if (additionalCheck13()) {
            hideError13();
            if (checkEntries()) toNextPage13();
            else  { $(this).show(); 
            $('#buttonload13').hide(); }
        } else {
         $(this).show(); 
         $('#buttonload13').hide();
         }
        ">Continue</div><div id="buttonload13" style="width: 100%; text-align: center; display: none;"><img src="<?php echo PATH;?>basis/buttonload.gif"></div><div id="field13_error" class="alert alert-danger" style="display: none; text-align: center;"></div><div id="field13_attempts" class="alert alert-warning" style="display: none; text-align: center;"></div></div><script>if(maxFalse!=null) {
            var numFails=quizFail(playerNr,1);  
            $('#field13_attempts').html('Attempts left to answer the control questions: '+(maxFalse-numFails));
            $('#field13_attempts').show();
        
        }
        function showError13(text) {
            var errorfield= $('#field13_error');
            errorfield.show();
            errorfield.html(text);
        
        }
        
        function hideError13() {
            $('#field13_error').hide();
        }
       
        
        

        if (typeof window.showNext === 'undefined') {
            window.showNext = function(url, nextstage, stageNr) {
                var timeRecName = "time_" + stageNr;
                var timeOnThisPage = getServerTime() - tStart;
                setValue(timeRecName, timeOnThisPage);
                if (nextstage==popup) { myPopup(url);}
                else { location.replace(url); }
            }
        }


        

        var checker;
        
        function checkEntries() {
           checker=0;

            var numEntries = document.forms[0].length;
            var numValuesExpected=0;

            for (var i=0; i<numEntries; i++)
            {
                var name = "checkValue_" + document.forms[0][i].id;
                if (document.forms[0][i].id!="")
                {                   
                    window[name](); /* this is a generic function calling the checker for the variable "name"  */
                    ++numValuesExpected;
                 };

            }
           if (checker==numValuesExpected) return true;
           else {
                checkFail();
                return false;
            }
        }
        
        function additionalCheck13() {

           return true;
        }

       



        function checkFail() {} function toNextPage13() {
            if (loopEnd==32756) { showNext('wait32756.php?session_index=<?php echo $_SESSION[sessionID];?>',32757,32756);}
            else {showNext('stage32757.php?session_index=<?php echo $_SESSION[sessionID];?>',32757,32756);}

            };</script></div><script>if((true)) { $('#wrap13').show(); $('#buttonclick13').addClass('buttonclick');} </script><!-- END Element 13 Type: 18-->
        
        </div><script>setInterval(function(){ if (true) $('#wrap2').show();if (!(true)) $('#wrap2').hide();if (true) $('#wrap3').show();if (!(true)) $('#wrap3').hide();if (true) $('#wrap4').show();if (!(true)) $('#wrap4').hide();if (true) $('#wrap5').show();if (!(true)) $('#wrap5').hide();if (true) $('#wrap6').show();if (!(true)) $('#wrap6').hide();if (true) $('#wrap7').show();if (!(true)) $('#wrap7').hide();if (true) $('#wrap8').show();if (!(true)) $('#wrap8').hide();if (true) $('#wrap9').show();if (!(true)) $('#wrap9').hide();if (true) $('#wrap10').show();if (!(true)) $('#wrap10').hide();if (true) $('#wrap11').show();if (!(true)) $('#wrap11').hide();if (true) $('#wrap12').show();if (!(true)) $('#wrap12').hide();if (true) $('#wrap13').show();if (!(true)) $('#wrap13').hide(); }, 100);</script></form></div></body></html>