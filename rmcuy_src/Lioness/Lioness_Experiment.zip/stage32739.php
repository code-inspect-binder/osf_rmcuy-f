<html>
        <head>
        <?php
  
        include("_projectID.php");
        session_start();
	    $_SESSION['projectID']=PROJECTID;
	    include(PATH."basis/LIONESS.php");
	    ?>

        <link href="<?php echo PATH;?>basis/newlayout.css" rel="stylesheet" type="text/css"  />
        <link href="<?php echo PATH;?>basis/newlayout_bootstrap.css" rel="stylesheet" type="text/css"  />
        <link href="<?php echo PATH;?>basis/grid.css" rel="stylesheet" type="text/css"  /><title>quiz TP</title>

        <script> var v={}; var wronganswers={};var maxFalse = null;
        var firstStageExp = <?php echo json_encode(FIRSTPAGE . ".php"); ?>;
        var thisPage = <?php echo json_encode($thisPage); ?>;
      
        pageRefreshed=0;
        var loopBegin = "stage" + loopStart + ".php";
        var afterLoopEnd = 32738;
        if (thisPage == firstStageExp || (thisPage==loopBegin && period > 1) || loopEnd==afterLoopEnd) firstStage();
        /* if (thisPage == firstStageExp || thisPage==loopBegin || loopEnd==afterLoopEnd) firstStage(); */
        TimeOut=null;
        function skipStage() {
         location.replace('wait32739.php?session_index=<?php echo $_SESSION[sessionID];?>');
        }
        $(document).ready(function(){
        if (bot) { document.getElementsByClassName("buttonclick")[0].click(); }
        });
        
        </script>
        </head>
        <body class="container" style="width: 100%; padding-left: 5%; padding-right: 5%; padding-top: 1%;"><form autocomplete="off"><div class="row"><!-- START Element 1 Type: 19-->
        
        </div><div class="row">
        <script></script><!-- END Element 1 Type: 19-->
        
        <!-- START Element 2 Type: 1-->
        
        </div><div class="row"><div id="wrap2" style="display: none;"><div class="btnbox2 paddlr" style="text-align: center"><h3>Check for understanding</h3><p>To check your understanding of the task, please indicate for each of these statements whether they are correct or incorrect.</div>
        </div><script>if((true)) { $('#wrap2').show(); } </script><!-- END Element 2 Type: 1-->
        
        <!-- START Element 3 Type: 23-->
        
        </div><div class="row"><div id="wrap3" style="display: none;"><div class="btnbox2"><div class="form-group "><input type="hidden" id="field3"><div style="text-align: center"><label for="field3"><b>In each round of this task you will view an image. You have to estimate how many animals were displayed in it.</b></label></div><div
            id="button31"

            class="choicebuttons3 btn btn-default" onclick="$('.choicebuttons3').removeClass('btn-primary');
            $('#button31').addClass('btn-primary');
            qR1=1;
            $('#field3').val(1);
            ">correct</div><div
            id="button32"

            class="choicebuttons3 btn btn-default" onclick="$('.choicebuttons3').removeClass('btn-primary');
            $('#button32').addClass('btn-primary');
            qR1=2;
            $('#field3').val(2);
            ">incorrect</div><div id="field3_noEntry" class="messagefield3 alert alert-danger" style="display: none;">Please indicate your response.</div><div id="field3_notcorrect" class="messagefield3 alert alert-danger" style="display: none;">The value you entered is not correct.</div></div></div><script>var qR1=null;function checkValue_field3() {
           var label="qR1";var required=1;var inline=0;var orderoptions=0;var graphical=1;var correct=1;var defaultvalue=null;var options=null;
            if(!(true)) { checker=checker+1; } else {
                var value;
                if (bot) { 
                    if (correct != null) { value = correct; }
                    else if (typeof bot_qR1 !== 'undefined') { value=bot_qR1; }
                    else { 
                    var allvalues=["1","2"];
                    var index=Math.floor(Math.random()*allvalues.length); 
                    value=allvalues[index]; }
                }
                else {
                value=($('#field3').val()); 
                }
                                
                $('.messagefield3').hide();
                allcorrect=checker+1;
                if ((isNaN(value) || value == "") && required==1) {
                    $('#field3_noEntry').show();
                }
                else if (value!=correct && correct != null && required!=0) {
                            $('#field3_notcorrect').show();
                        }
                
                else {
                        

                       record("qR1", value);

                            /* this variable is created in LionElementButton.class */
                           checker = checker+1;


                }
            
            if (allcorrect!=checker) {
                  wronganswers['qR1']=1;
               } else wronganswers['qR1']=0;
            
            
            }
            
            
            
         }



        </script></div><script>if((true)) { $('#wrap3').show(); } </script><!-- END Element 3 Type: 23-->
        
        <!-- START Element 4 Type: 23-->
        
        </div><div class="row"><div id="wrap4" style="display: none;"><div class="btnbox2"><div class="form-group "><input type="hidden" id="field4"><div style="text-align: center"><label for="field4"><br><b>Once you have entered your estimate, the round is over.</b></label></div><div
            id="button41"

            class="choicebuttons4 btn btn-default" onclick="$('.choicebuttons4').removeClass('btn-primary');
            $('#button41').addClass('btn-primary');
            qR2=1;
            $('#field4').val(1);
            ">correct</div><div
            id="button42"

            class="choicebuttons4 btn btn-default" onclick="$('.choicebuttons4').removeClass('btn-primary');
            $('#button42').addClass('btn-primary');
            qR2=2;
            $('#field4').val(2);
            ">incorrect</div><div id="field4_noEntry" class="messagefield4 alert alert-danger" style="display: none;">Please indicate your response.</div><div id="field4_notcorrect" class="messagefield4 alert alert-danger" style="display: none;">The value you entered is not correct.</div></div></div><script>var qR2=null;function checkValue_field4() {
           var label="qR2";var required=1;var inline=0;var orderoptions=0;var graphical=1;var correct=2;var defaultvalue=null;var options=null;
            if(!(true)) { checker=checker+1; } else {
                var value;
                if (bot) { 
                    if (correct != null) { value = correct; }
                    else if (typeof bot_qR2 !== 'undefined') { value=bot_qR2; }
                    else { 
                    var allvalues=["1","2"];
                    var index=Math.floor(Math.random()*allvalues.length); 
                    value=allvalues[index]; }
                }
                else {
                value=($('#field4').val()); 
                }
                                
                $('.messagefield4').hide();
                allcorrect=checker+1;
                if ((isNaN(value) || value == "") && required==1) {
                    $('#field4_noEntry').show();
                }
                else if (value!=correct && correct != null && required!=0) {
                            $('#field4_notcorrect').show();
                        }
                
                else {
                        

                       record("qR2", value);

                            /* this variable is created in LionElementButton.class */
                           checker = checker+1;


                }
            
            if (allcorrect!=checker) {
                  wronganswers['qR2']=1;
               } else wronganswers['qR2']=0;
            
            
            }
            
            
            
         }



        </script></div><script>if((true)) { $('#wrap4').show(); } </script><!-- END Element 4 Type: 23-->
        
        <!-- START Element 5 Type: 23-->
        
        </div><div class="row"><div id="wrap5" style="display: none;"><div class="btnbox2"><div class="form-group "><input type="hidden" id="field5"><div style="text-align: center"><label for="field5"><br><b>Once you have entered your estimate, you can observe the estimate of three other MTurkers who completed this task before. You can then make a second estimate.</b></label></div><div
            id="button51"

            class="choicebuttons5 btn btn-default" onclick="$('.choicebuttons5').removeClass('btn-primary');
            $('#button51').addClass('btn-primary');
            qR2=1;
            $('#field5').val(1);
            ">correct</div><div
            id="button52"

            class="choicebuttons5 btn btn-default" onclick="$('.choicebuttons5').removeClass('btn-primary');
            $('#button52').addClass('btn-primary');
            qR2=2;
            $('#field5').val(2);
            ">incorrect</div><div id="field5_noEntry" class="messagefield5 alert alert-danger" style="display: none;">Please indicate your response.</div><div id="field5_notcorrect" class="messagefield5 alert alert-danger" style="display: none;">The value you entered is not correct.</div></div></div><script>var qR2=null;function checkValue_field5() {
           var label="qR2";var required=1;var inline=0;var orderoptions=0;var graphical=1;var correct=1;var defaultvalue=null;var options=null;
            if(!(true)) { checker=checker+1; } else {
                var value;
                if (bot) { 
                    if (correct != null) { value = correct; }
                    else if (typeof bot_qR2 !== 'undefined') { value=bot_qR2; }
                    else { 
                    var allvalues=["1","2"];
                    var index=Math.floor(Math.random()*allvalues.length); 
                    value=allvalues[index]; }
                }
                else {
                value=($('#field5').val()); 
                }
                                
                $('.messagefield5').hide();
                allcorrect=checker+1;
                if ((isNaN(value) || value == "") && required==1) {
                    $('#field5_noEntry').show();
                }
                else if (value!=correct && correct != null && required!=0) {
                            $('#field5_notcorrect').show();
                        }
                
                else {
                        

                       record("qR2", value);

                            /* this variable is created in LionElementButton.class */
                           checker = checker+1;


                }
            
            if (allcorrect!=checker) {
                  wronganswers['qR2']=1;
               } else wronganswers['qR2']=0;
            
            
            }
            
            
            
         }



        </script></div><script>if((true)) { $('#wrap5').show(); } </script><!-- END Element 5 Type: 23-->
        
        <!-- START Element 6 Type: 23-->
        
        </div><div class="row"><div id="wrap6" style="display: none;"><div class="btnbox2"><div class="form-group "><input type="hidden" id="field6"><div style="text-align: center"><label for="field6"><br><b>The more accurate your estimates, the more points you can earn.</b></label></div><div
            id="button61"

            class="choicebuttons6 btn btn-default" onclick="$('.choicebuttons6').removeClass('btn-primary');
            $('#button61').addClass('btn-primary');
            qR2=1;
            $('#field6').val(1);
            ">correct</div><div
            id="button62"

            class="choicebuttons6 btn btn-default" onclick="$('.choicebuttons6').removeClass('btn-primary');
            $('#button62').addClass('btn-primary');
            qR2=2;
            $('#field6').val(2);
            ">incorrect</div><div id="field6_noEntry" class="messagefield6 alert alert-danger" style="display: none;">Please indicate your response.</div><div id="field6_notcorrect" class="messagefield6 alert alert-danger" style="display: none;">The value you entered is not correct.</div></div></div><script>var qR2=null;function checkValue_field6() {
           var label="qR2";var required=1;var inline=0;var orderoptions=0;var graphical=1;var correct=1;var defaultvalue=null;var options=null;
            if(!(true)) { checker=checker+1; } else {
                var value;
                if (bot) { 
                    if (correct != null) { value = correct; }
                    else if (typeof bot_qR2 !== 'undefined') { value=bot_qR2; }
                    else { 
                    var allvalues=["1","2"];
                    var index=Math.floor(Math.random()*allvalues.length); 
                    value=allvalues[index]; }
                }
                else {
                value=($('#field6').val()); 
                }
                                
                $('.messagefield6').hide();
                allcorrect=checker+1;
                if ((isNaN(value) || value == "") && required==1) {
                    $('#field6_noEntry').show();
                }
                else if (value!=correct && correct != null && required!=0) {
                            $('#field6_notcorrect').show();
                        }
                
                else {
                        

                       record("qR2", value);

                            /* this variable is created in LionElementButton.class */
                           checker = checker+1;


                }
            
            if (allcorrect!=checker) {
                  wronganswers['qR2']=1;
               } else wronganswers['qR2']=0;
            
            
            }
            
            
            
         }



        </script></div><script>if((true)) { $('#wrap6').show(); } </script><!-- END Element 6 Type: 23-->
        
        <!-- START Element 7 Type: 18-->
        
        </div><div class="row"><div id="wrap7" style="display: none;">
        <script>
       
        
        </script>
        
        <div  id="button7">
        <div id="buttonclick7" class="btn btn-default btn-lg btn-block " style=" white-space:normal !important; word-wrap: break-word;" onclick="
        $(this).hide(); $('#buttonload7').show();
        if (additionalCheck7()) {
            hideError7();
            if (checkEntries()) toNextPage7();
            else  { $(this).show(); 
            $('#buttonload7').hide(); }
        } else {
         $(this).show(); 
         $('#buttonload7').hide();
         }
        ">Continue</div><div id="buttonload7" style="width: 100%; text-align: center; display: none;"><img src="<?php echo PATH;?>basis/buttonload.gif"></div><div id="field7_error" class="alert alert-danger" style="display: none; text-align: center;"></div><div id="field7_attempts" class="alert alert-warning" style="display: none; text-align: center;"></div></div><script>if(maxFalse!=null) {
            var numFails=quizFail(playerNr,1);  
            $('#field7_attempts').html('Attempts left to answer the control questions: '+(maxFalse-numFails));
            $('#field7_attempts').show();
        
        }
        function showError7(text) {
            var errorfield= $('#field7_error');
            errorfield.show();
            errorfield.html(text);
        
        }
        
        function hideError7() {
            $('#field7_error').hide();
        }
       
        
        

        if (typeof window.showNext === 'undefined') {
            window.showNext = function(url, nextstage, stageNr) {
                var timeRecName = "time_" + stageNr;
                var timeOnThisPage = getServerTime() - tStart;
                setValue(timeRecName, timeOnThisPage);
                if (nextstage==popup) { myPopup(url);}
                else { location.replace(url); }
            }
        }


        

        var checker;
        
        function checkEntries() {
           checker=0;

            var numEntries = document.forms[0].length;
            var numValuesExpected=0;

            for (var i=0; i<numEntries; i++)
            {
                var name = "checkValue_" + document.forms[0][i].id;
                if (document.forms[0][i].id!="")
                {                   
                    window[name](); /* this is a generic function calling the checker for the variable "name"  */
                    ++numValuesExpected;
                 };

            }
           if (checker==numValuesExpected) return true;
           else {
                checkFail();
                return false;
            }
        }
        
        function additionalCheck7() {

           return true;
        }

       



        function checkFail() {var numFails=quizFail(playerNr,0,wronganswers);
            console.log(numFails);
            if (numFails>=maxFalse && maxFalse!=null) location.replace(path+'HITstop.php?m=<?php echo base64_encode(serialize(array('messageNr'=>8,'projectID'=>PROJECTID))); ?>');
            if (maxFalse!=null && numFails<=maxFalse) $('#field7_attempts').html('Attempts left to answer the control questions: '+(maxFalse-numFails));
            } function toNextPage7() {
            if (loopEnd==32739) { showNext('wait32739.php?session_index=<?php echo $_SESSION[sessionID];?>',32740,32739);}
            else {showNext('stage32740.php?session_index=<?php echo $_SESSION[sessionID];?>',32740,32739);}

            };</script></div><script>if((true)) { $('#wrap7').show(); $('#buttonclick7').addClass('buttonclick');} </script><!-- END Element 7 Type: 18-->
        
        <!-- START Element 8 Type: 25-->
        
        </div><div class="row"><div id="wrap8" style="display: none;"><div  id="button8">
        <div class="btn btn-default btn-lg btn-block" onclick="toNextPage8();">Back to instructions</div></div><script>



      


         function toNextPage8() {
            showNext('stage32738.php?session_index=<?php echo $_SESSION[sessionID];?>',32738,32739);

            };</script></div><script>if((true)) { $('#wrap8').show(); } </script><!-- END Element 8 Type: 25-->
        
        </div><script>setInterval(function(){ if (true) $('#wrap2').show();if (!(true)) $('#wrap2').hide();if (true) $('#wrap3').show();if (!(true)) $('#wrap3').hide();if (true) $('#wrap4').show();if (!(true)) $('#wrap4').hide();if (true) $('#wrap5').show();if (!(true)) $('#wrap5').hide();if (true) $('#wrap6').show();if (!(true)) $('#wrap6').hide();if (true) $('#wrap7').show();if (!(true)) $('#wrap7').hide();if (true) $('#wrap8').show();if (!(true)) $('#wrap8').hide(); }, 100);</script></form></div></body></html>