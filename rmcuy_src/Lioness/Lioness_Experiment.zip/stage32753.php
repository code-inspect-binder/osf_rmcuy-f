<html>
        <head>
        <?php
  
        include("_projectID.php");
        session_start();
	    $_SESSION['projectID']=PROJECTID;
	    include(PATH."basis/LIONESS.php");
	    ?>

        <link href="<?php echo PATH;?>basis/newlayout.css" rel="stylesheet" type="text/css"  />
        <link href="<?php echo PATH;?>basis/newlayout_bootstrap.css" rel="stylesheet" type="text/css"  />
        <link href="<?php echo PATH;?>basis/grid.css" rel="stylesheet" type="text/css"  /><title>questionnaire 1</title>

        <script> var v={}; var wronganswers={};var maxFalse = null;
        var firstStageExp = <?php echo json_encode(FIRSTPAGE . ".php"); ?>;
        var thisPage = <?php echo json_encode($thisPage); ?>;
      
        pageRefreshed=0;
        var loopBegin = "stage" + loopStart + ".php";
        var afterLoopEnd = 32752;
        if (thisPage == firstStageExp || (thisPage==loopBegin && period > 1) || loopEnd==afterLoopEnd) firstStage();
        /* if (thisPage == firstStageExp || thisPage==loopBegin || loopEnd==afterLoopEnd) firstStage(); */
        TimeOut=null;
        function skipStage() {
         location.replace('wait32753.php?session_index=<?php echo $_SESSION[sessionID];?>');
        }
        $(document).ready(function(){
        if (bot) { document.getElementsByClassName("buttonclick")[0].click(); }
        });
        
        </script>
        </head>
        <body class="container" style="width: 100%; padding-left: 5%; padding-right: 5%; padding-top: 1%;"><form autocomplete="off"><div class="row"><!-- START Element 1 Type: 19-->
        
        </div><div class="row">
        <script></script><!-- END Element 1 Type: 19-->
        
        <!-- START Element 2 Type: 1-->
        
        </div><div class="row"><div id="wrap2" style="display: none;"><div class="btnbox2 paddlr" style="text-align: center"><h3>Questionnaire 1 of 5
</h3><p>The image below shows 7 pairs of circles. The &#039;X&#039; signs stand for other MTurkers from the USA. <br><br> 
<img src="http://www.surveycamel.com/hively/animalPictures/IOS_pic.PNG" width="400px"></div>
        </div><script>if((true)) { $('#wrap2').show(); } </script><!-- END Element 2 Type: 1-->
        
        <!-- START Element 3 Type: 23-->
        
        </div><div class="row"><div id="wrap3" style="display: none;"><div class="btnbox2"><div class="form-group "><input type="hidden" id="field3"><div style="text-align: center"><label for="field3"><b>Which of these pairs best describes your relationship with these other MTurkers?</b></label></div><div
            id="button31"

            class="choicebuttons3 btn btn-default" onclick="$('.choicebuttons3').removeClass('btn-primary');
            $('#button31').addClass('btn-primary');
            IOS=1;
            $('#field3').val(1);
            ">#1</div><div
            id="button32"

            class="choicebuttons3 btn btn-default" onclick="$('.choicebuttons3').removeClass('btn-primary');
            $('#button32').addClass('btn-primary');
            IOS=2;
            $('#field3').val(2);
            ">#2</div><div
            id="button33"

            class="choicebuttons3 btn btn-default" onclick="$('.choicebuttons3').removeClass('btn-primary');
            $('#button33').addClass('btn-primary');
            IOS=3;
            $('#field3').val(3);
            ">#3</div><div
            id="button34"

            class="choicebuttons3 btn btn-default" onclick="$('.choicebuttons3').removeClass('btn-primary');
            $('#button34').addClass('btn-primary');
            IOS=4;
            $('#field3').val(4);
            ">#4</div><div
            id="button35"

            class="choicebuttons3 btn btn-default" onclick="$('.choicebuttons3').removeClass('btn-primary');
            $('#button35').addClass('btn-primary');
            IOS=5;
            $('#field3').val(5);
            ">#5</div><div
            id="button36"

            class="choicebuttons3 btn btn-default" onclick="$('.choicebuttons3').removeClass('btn-primary');
            $('#button36').addClass('btn-primary');
            IOS=6;
            $('#field3').val(6);
            ">#6</div><div
            id="button37"

            class="choicebuttons3 btn btn-default" onclick="$('.choicebuttons3').removeClass('btn-primary');
            $('#button37').addClass('btn-primary');
            IOS=7;
            $('#field3').val(7);
            ">#7</div><div id="field3_noEntry" class="messagefield3 alert alert-danger" style="display: none;">Please indicate your response.</div><div id="field3_notcorrect" class="messagefield3 alert alert-danger" style="display: none;">The value you entered is not correct.</div></div></div><script>var IOS=null;function checkValue_field3() {
           var label="IOS";var required=1;var inline=0;var orderoptions=0;var graphical=1;var correct=null;var defaultvalue=null;var options=null;
            if(!(true)) { checker=checker+1; } else {
                var value;
                if (bot) { 
                    if (correct != null) { value = correct; }
                    else if (typeof bot_IOS !== 'undefined') { value=bot_IOS; }
                    else { 
                    var allvalues=["1","2","3","4","5","6","7"];
                    var index=Math.floor(Math.random()*allvalues.length); 
                    value=allvalues[index]; }
                }
                else {
                value=($('#field3').val()); 
                }
                                
                $('.messagefield3').hide();
                allcorrect=checker+1;
                if ((isNaN(value) || value == "") && required==1) {
                    $('#field3_noEntry').show();
                }
                else if (value!=correct && correct != null && required!=0) {
                            $('#field3_notcorrect').show();
                        }
                
                else {
                        

                       record("IOS", value);

                            /* this variable is created in LionElementButton.class */
                           checker = checker+1;


                }
            
            if (allcorrect!=checker) {
                  wronganswers['IOS']=1;
               } else wronganswers['IOS']=0;
            
            
            }
            
            
            
         }



        </script></div><script>if((true)) { $('#wrap3').show(); } </script><!-- END Element 3 Type: 23-->
        
        <!-- START Element 4 Type: 18-->
        
        </div><div class="row"><div id="wrap4" style="display: none;">
        <script>
       
        
        </script>
        
        <div  id="button4">
        <div id="buttonclick4" class="btn btn-default btn-lg btn-block " style=" white-space:normal !important; word-wrap: break-word;" onclick="
        $(this).hide(); $('#buttonload4').show();
        if (additionalCheck4()) {
            hideError4();
            if (checkEntries()) toNextPage4();
            else  { $(this).show(); 
            $('#buttonload4').hide(); }
        } else {
         $(this).show(); 
         $('#buttonload4').hide();
         }
        ">Continue</div><div id="buttonload4" style="width: 100%; text-align: center; display: none;"><img src="<?php echo PATH;?>basis/buttonload.gif"></div><div id="field4_error" class="alert alert-danger" style="display: none; text-align: center;"></div><div id="field4_attempts" class="alert alert-warning" style="display: none; text-align: center;"></div></div><script>if(maxFalse!=null) {
            var numFails=quizFail(playerNr,1);  
            $('#field4_attempts').html('Attempts left to answer the control questions: '+(maxFalse-numFails));
            $('#field4_attempts').show();
        
        }
        function showError4(text) {
            var errorfield= $('#field4_error');
            errorfield.show();
            errorfield.html(text);
        
        }
        
        function hideError4() {
            $('#field4_error').hide();
        }
       
        
        

        if (typeof window.showNext === 'undefined') {
            window.showNext = function(url, nextstage, stageNr) {
                var timeRecName = "time_" + stageNr;
                var timeOnThisPage = getServerTime() - tStart;
                setValue(timeRecName, timeOnThisPage);
                if (nextstage==popup) { myPopup(url);}
                else { location.replace(url); }
            }
        }


        

        var checker;
        
        function checkEntries() {
           checker=0;

            var numEntries = document.forms[0].length;
            var numValuesExpected=0;

            for (var i=0; i<numEntries; i++)
            {
                var name = "checkValue_" + document.forms[0][i].id;
                if (document.forms[0][i].id!="")
                {                   
                    window[name](); /* this is a generic function calling the checker for the variable "name"  */
                    ++numValuesExpected;
                 };

            }
           if (checker==numValuesExpected) return true;
           else {
                checkFail();
                return false;
            }
        }
        
        function additionalCheck4() {

           return true;
        }

       



        function checkFail() {} function toNextPage4() {
            if (loopEnd==32753) { showNext('wait32753.php?session_index=<?php echo $_SESSION[sessionID];?>',32754,32753);}
            else {showNext('stage32754.php?session_index=<?php echo $_SESSION[sessionID];?>',32754,32753);}

            };</script></div><script>if((true)) { $('#wrap4').show(); $('#buttonclick4').addClass('buttonclick');} </script><!-- END Element 4 Type: 18-->
        
        </div><script>setInterval(function(){ if (true) $('#wrap2').show();if (!(true)) $('#wrap2').hide();if (true) $('#wrap3').show();if (!(true)) $('#wrap3').hide();if (true) $('#wrap4').show();if (!(true)) $('#wrap4').hide(); }, 100);</script></form></div></body></html>