<?php define ("PROJECTID","e537g9265_");
	    define ("PATH","resources/");
	    define ("FIRSTPAGE","stage32725");
	    define ("PROJECTPW","26d15fc8f0fefd18b6c9b5544a571778");
	    