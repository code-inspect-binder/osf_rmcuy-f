<html>
        <head>
        <?php
  
        include("_projectID.php");
        session_start();
	    $_SESSION['projectID']=PROJECTID;
	    include(PATH."basis/LIONESS.php");
	    ?>

        <link href="<?php echo PATH;?>basis/newlayout.css" rel="stylesheet" type="text/css"  />
        <link href="<?php echo PATH;?>basis/newlayout_bootstrap.css" rel="stylesheet" type="text/css"  />
        <link href="<?php echo PATH;?>basis/grid.css" rel="stylesheet" type="text/css"  /><title>estimate FP</title>

        <script> var v={}; var wronganswers={};var maxFalse = null;
        var firstStageExp = <?php echo json_encode(FIRSTPAGE . ".php"); ?>;
        var thisPage = <?php echo json_encode($thisPage); ?>;
      
        pageRefreshed=0;
        var loopBegin = "stage" + loopStart + ".php";
        var afterLoopEnd = 32750;
        if (thisPage == firstStageExp || (thisPage==loopBegin && period > 1) || loopEnd==afterLoopEnd) firstStage();
        /* if (thisPage == firstStageExp || thisPage==loopBegin || loopEnd==afterLoopEnd) firstStage(); */
        TimeOut=30;
        function skipStage() {
         location.replace('wait32751.php?session_index=<?php echo $_SESSION[sessionID];?>');
        }
        $(document).ready(function(){
        if (bot) { document.getElementsByClassName("buttonclick")[0].click(); }
        });
        
        </script>
        </head>
        <body class="container" style="width: 100%; padding-left: 5%; padding-right: 5%; padding-top: 1%;"><form autocomplete="off"><div class="row"><!-- START Element 1 Type: 19-->
        
        </div><div class="row">
        <script>var counter = getInt('counterIII');
if (counter == 1) TimeOut=45;

//record treatment
treatment = 7;
setValue('treatment',treatment);

var v = 0;
if (bot) v = 50+Math.floor(Math.random(1)*50);

est = '4peerest' + parseFloat(counter);
prev_est =getValue('decisions', 'playerNr='+playerNr+' and period='+1, est);

var animal_names =['ant', 'bee', 'flamingo', 'crane', 'cricket'];
var numbers = [60,77,93,85,58];
var animalnum = numbers[counter-1];
var animalname = animal_names[counter-1];

setValue('nAnimals', animalnum);
setValue('animalName', animalname);
setValue('firstEstimate',prev_est);</script><!-- END Element 1 Type: 19-->
        
        <!-- START Element 2 Type: 19-->
        
        </div><div class="row">
        <script>p1 = [
[ 22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,22,23,25,25,26,28,28,31,31,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,53,53,55,55,56,57,60,60,60,62,39,40,40,42,42,43,43,45,45,46,47,47,49,49,50,51,51,53,53,55,55,56,56,57,57,60,60,60,60,60,65,65,65,65,66,66,66,70,70,70,70,70,71,75,75,75,75,75,77,77,77,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80],
[ 25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,26,30,30,30,30,31,32,33,34,35,36,37,38,40,41,41,42,44,45,46,46,48,50,51,53,54,54,57,57,57,61,61,62,63,64,65,67,67,71,71,71,72,72,75,75,79,79,79,79,79,85,85,85,51,51,53,53,54,54,56,57,57,60,60,60,60,62,62,63,64,64,65,66,67,67,70,70,70,72,72,72,72,75,75,75,75,79,79,79,79,79,79,79,85,85,85,85,85,85,91,91,91,91,91,91,94,94,94,94,94,96,96,96,96,96,105,105,105,105,105,105,105,105,105,105,105],
[ 33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,33,38,38,38,38,43,43,43,45,46,47,49,49,50,52,54,54,55,58,59,60,61,62,62,65,65,68,68,68,70,71,73,74,75,77,77,78,80,81,83,84,84,85,87,89,90,91,91,93,94,96,96,97,98,100,102,102,105,105,106,106,110,73,73,74,75,76,77,77,77,78,80,81,81,81,83,84,85,84,85,86,87,89,89,90,91,92,92,93,94,94,96,97,97,97,98,100,100,100,103,102,103,105,105,106,106,106,106,110,110,110,110,113,113,115,115,115,115,115],
[58,65,75,52,54,47,88,68,59,52,75,40,56,70,54,56,55,44,31,75,44,58,46,55,40,31,46,41,60,41,33,64,75,80,58,44,80,46,44,71,52,40,76,63,52,48,46,79,85,65,77,54,47,31,46,41,66,44,77,44,59,92,45,60,56,101,41,31,44,59,58,45,91,75,103,31,68,64,65,79,44,66,62,65,56,40,62,62,54,66,60,63,46,45,40,41,31,31,63,63,84,40,60,69,45,52,45,70,60,55,46,44,45,60,40,71,59,44,56,31,47,61,69,60,91,61,66,41,56,81,31,31,47,62,41,52,41,65,60,65,40,40,45,31,31,46,41,58,55,52,52],
[ 18,18,18,18,18,18,18,18,18,18,18,18,18,18,18,18,18,19,22,22,22,26,26,26,26,27,30,30,30,31,32,34,34,35,36,38,38,39,40,41,42,43,44,45,46,47,48,49,50,52,52,53,54,55,56,58,58,59,40,41,42,43,43,43,46,46,48,48,49,49,50,50,52,53,54,54,54,56,56,58,58,58,61,61,61,61,61,61,61,67,67,67,67,69,70,70,71,71,71,71,71,71,71,71,75,75,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80],
];

p2 = [
[ 23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,23,25,26,26,28,32,32,32,32,32,33,34,35,36,37,38,39,41,42,45,45,47,48,55,51,57,54,59,60,60,59,62,65,65,66,67,70,70,70,71,49,50,50,51,51,53,53,55,55,56,57,57,59,59,60,60,62,62,63,65,65,66,66,67,67,70,70,70,70,70,75,75,75,75,76,76,76,80,80,80,80,80,86,85,85,85,85,85,86,90,90,90,95,95,95,95,95,95,95,95,95,95,95,95,95,95,95,95,95,95,95,95,95,95,95,95,95,95,95,95,95,95,95,95,95,95,95,95,95,95],
[ 26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,26,30,31,31,31,31,32,33,34,35,36,37,38,40,41,42,42,45,45,46,48,50,51,51,53,54,55,56,59,59,59,62,62,63,65,66,67,68,69,72,72,72,75,75,79,79,80,80,80,80,80,89,89,89,67,68,69,70,71,71,71,72,72,75,75,75,75,79,79,79,80,81,82,82,83,83,85,85,85,89,89,89,89,90,90,91,91,95,95,95,95,95,95,95,96,96,96,96,96,96,105,105,105,105,105,105,105,105,105,105,105,112,112,112,112,112,112,112,112,112,112,112,112,112,112,112,112],
[ 38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,38,43,43,43,45,45,45,47,47,50,50,50,54,54,55,55,59,60,60,60,62,62,65,68,68,69,69,70,73,74,75,76,76,78,78,81,83,82,84,84,85,89,90,90,91,91,93,96,97,98,97,100,102,103,103,105,105,106,106,110,110,113,75,75,76,77,77,78,80,82,83,81,82,84,86,85,85,86,89,90,91,91,91,91,92,93,93,96,97,96,98,97,98,100,102,102,102,103,105,105,105,106,106,106,110,110,110,113,113,113,115,115,114,116,116,116,116,116,116],
[97,66,78,74,87,88,96,84,65,64,87,81,67,80,62,79,63,60,99,88,46,76,96,66,70,44,110,103,65,64,79,105,86,81,76,56,100,55,67,81,67,52,91,66,64,63,74,94,91,101,101,64,77,92,84,84,91,84,101,66,78,94,64,71,58,104,56,92,45,63,61,86,92,87,105,65,70,65,106,92,75,97,85,91,115,63,76,85,97,86,87,91,71,67,41,61,58,65,81,86,99,60,88,77,77,66,64,86,99,87,68,62,55,84,99,96,85,68,61,59,61,69,70,90,106,87,74,79,105,99,64,71,100,63,59,65,54,70,69,85,47,70,60,69,97,60,54,79,75,68,68],

[ 34,34,34,34,34,34,34,34,34,34,34,34,34,34,34,34,34,35,38,38,38,42,42,42,42,43,46,46,46,47,48,50,50,52,52,54,54,55,56,58,58,59,60,60,61,61,64,66,66,69,69,69,70,71,72,74,74,74,42,43,44,45,45,45,47,48,49,49,50,50,52,54,53,54,55,56,56,58,59,59,59,59,64,64,64,64,66,66,66,69,69,69,70,70,71,72,72,72,72,72,72,72,72,72,80,80,86,86,86,86,86,86,86,86,86,86,86,86,86,86,86,86,86,86,86,86,86,86,86,86,86,86,86,86,86,86,86,86,86,86,86,86,86,86,86,86,86,86,86,86],
];

p3 = [
[ 40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,40,41,43,43,44,47,47,49,49,49,50,51,51,53,54,55,56,57,58,60,60,62,63,65,65,67,67,69,70,71,72,72,75,75,76,77,80,80,80,80,59,60,60,62,62,63,63,65,65,66,67,67,69,69,70,71,71,72,72,75,75,76,76,77,77,80,80,80,80,80,85,85,85,85,86,86,86,90,90,90,90,90,90,95,95,95,95,95,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98],
[ 42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,42,45,48,48,48,48,48,50,51,51,53,54,55,56,57,59,59,61,62,63,64,65,67,68,69,71,72,72,75,75,75,79,79,80,81,82,83,85,85,89,89,89,91,91,94,94,96,96,96,96,96,105,105,105,69,69,71,71,72,72,75,75,75,79,79,79,79,80,80,81,82,82,83,85,85,85,89,89,89,90,90,90,90,94,94,94,94,96,96,96,96,96,96,96,105,105,105,105,105,105,112,112,112,112,112,112,112,112,112,112,112,120,120,120,120,120,120,120,120,120,120,120,120,120,120,120,120],
[ 43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,43,45,45,45,46,46,49,50,52,52,54,55,55,58,58,60,60,61,62,65,65,68,68,69,69,71,73,74,75,76,77,78,80,81,83,83,84,86,87,89,90,90,91,93,94,96,97,97,98,100,102,103,103,105,106,106,110,110,113,113,113,114,78,80,80,81,82,83,83,83,84,86,87,87,87,89,90,91,91,91,92,93,94,96,96,97,98,98,98,100,100,102,103,103,103,105,106,106,106,106,110,110,110,113,113,113,113,114,114,116,116,116,119,119,119,119,119,119,119],
[100,69,84,81,117,90,106,94,92,70,105,88,110,94,121,86,104,81,108,103,99,121,117,86,92,108,115,115,121,85,99,121,105,121,81,80,121,97,92,94,68,67,97,84,80,99,78,99,105,121,121,96,117,105,96,90,106,86,108,103,104,108,96,115,67,140,69,140,121,66,96,92,117,106,106,105,108,115,140,110,79,99,105,100,121,91,103,115,104,121,108,140,78,110,108,99,115,103,104,104,110,81,104,81,106,84,92,117,105,92,117,64,80,99,121,99,101,77,78,80,85,74,100,121,108,94,110,92,140,101,94,117,105,77,76,96,90,75,75,121,66,84,100,97,108,66,105,80,86,100,100],
[ 36,36,36,36,36,36,36,36,36,36,36,36,36,36,36,36,36,36,40,40,40,44,44,44,44,45,48,48,48,49,50,52,52,53,54,56,56,56,58,59,60,61,61,64,64,66,66,67,67,70,70,71,72,72,74,75,75,75,58,59,60,61,61,61,64,64,66,66,67,67,69,69,70,71,72,72,72,74,75,75,75,75,80,80,80,80,80,80,80,86,86,86,86,86,88,88,89,89,89,89,89,89,89,89,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98,98],
];</script><!-- END Element 2 Type: 19-->
        
        <!-- START Element 3 Type: 1-->
        
        </div><div class="row"><div id="wrap3" style="display: none;"><div class="btnbox2 paddlr" style="text-align: center"><h3>Round <script>document.write(counter)</script>: your estimate</h3>The red dots show the estimates of four other MTurkers.<br><br></div>
        </div><script>if((true)) { $('#wrap3').show(); } </script><!-- END Element 3 Type: 1-->
        
        <!-- START Element 4 Type: 1-->
        
        </div><div class="row"><div id="wrap4" style="display: none;"><div class="btnbox2 paddlr" style="text-align: center"><div style="text-align: left;"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css"><script src="https://code.jquery.com/jquery-1.12.4.js"></script><script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script><style type="text/css">

#slider label {
    position: absolute;
    width: 25px;
    margin-left: -10px;
    text-align: center;
    margin-top: 20px;
}

/* below is not necessary, just for style */
#slider {
    width: 100%;
    margin: 2em auto;
}

.pointer
{
    position: absolute;
    color: white;
    font-size: 16.5px;
    
 }
 
   .pointer_down,  .pointer_up
  {
     background-size: cover;
      left: -6px;     
  } 
 
 .pointer_down
 {
   background-image: url(http://www.surveycamel.com/hively/IMGs/box_up.svg);
   top: 0px;
    width: 32px;
    height: 32px;
    }
 
 .pointer_up
 {
   background-image: url(http://www.surveycamel.com/hively/IMGs/box_down.svg);
   top: -50px;
    width: 32px;
    height: 32px;
    text-align:center;
 }
 
.block label {
display: inline-block; width: 200px; height:400px; text-align: left; font-size:1.5em
}

.block input {
  font-size: 5em
}
.ui-slider .ui-slider-handle{
    width:8px; 
    height:30px; 
    position:absolute;
    top: -10px;
    margin-left:-5px;
    border-color:rgb(0,100,255);
    border-width:2px;
    text-align: center;
    background:yellow ;
}


</style></div>

<table style="margin:auto">
<tr>
  <td style="">
    <div class="block" style=" font-size:1em; text-align: center;">
  Your estimate is:&nbsp
  </td>
  <td style="width:50px">
     <div id="amount" style="font-size:1em; border:0; color:rgb(0,100,255); font-weight:bold;  display: inline;"></div>
  </td>
</tr>
</table>
<br>
<div id="slider"></div><br></div>
        </div><script>if((true)) { $('#wrap4').show(); } </script><!-- END Element 4 Type: 1-->
        
        <!-- START Element 5 Type: 19-->
        
        </div><div class="row">
        <script>$( "#slider" ).slider({
	value: 0,
	min: 0,
	max: 150,
	step: 1,
    
    slide: function( event, ui ) {
        $( "#amount" ).html(ui.value );
      },
    stop: function(event, ui) {
      v =  $('#slider').slider("value");
      }
 }).each ( function() {

	var opt = $(this).data().uiSlider.options;

	// Get the number of possible values
	var vals = opt.max - opt.min;
			
	 // on which steps the symbols should be placed?
	var positions = [prev_est, p1[counter-1][prev_est-1], p2[counter-1][prev_est-1], p3[counter-1][prev_est-1]];
	setValue('p1',positions[1]);	
	setValue('p2',positions[2]);
	setValue('p3',positions[3]);
	
	//sort positions for displaying info
	
  positions.sort(function(a, b){return a-b});
  var pos_counter = 0;
  
  
  // when two estimates closer together than this offset we will place the second pointer above the slider
  // try different values for this
  var offset = 2;
  var pointer_class = "pointer_down";

	for (var i = 0; i <= vals; i++)
	{
		if ( positions.indexOf (i) != -1 )
		{	
    	if (pos_counter > 0 && positions[pos_counter] - positions[pos_counter - 1] <= offset)
      {
      	pointer_class = pointer_class == 'pointer_down' ? 'pointer_up' : 'pointer_down';
      }
			var el = $('<label><img src="http://www.surveycamel.com/hively/IMGs/circle.svg" width=20 height=20 style="position: absolute; top: -25px; left: 0px;" /><div class="pointer ' + pointer_class + '">' + positions[pos_counter] + '</div></label>').css('left',(i/vals*100)+'%');
      pos_counter++;
      
      $( "#slider" ).append(el);
            
		}}
	
});

$("#slider .ui-slider-handle").focus();
 
 document.onclick = function()
 {
  $("#slider .ui-slider-handle").focus();
 };</script><!-- END Element 5 Type: 19-->
        
        <!-- START Element 6 Type: 19-->
        
        </div><div class="row">
        <script>// example triplet (as extracted from the 3 matrices)
var ps = [p1[counter-1][prev_est-1], p2[counter-1][prev_est-1], p3[counter-1][prev_est-1]];

// calculate mean
sum=0.0;
for (i=0;i<3;i++) sum=sum+ps[i];
meanP=sum/3.0;

// calculate variance
sum=0.0;
for (i=0;i<3;i++) sum=sum+Math.pow(ps[i]-meanP,2);
varP=sum/2.0;

// calculate skewness
sum=0.0;
sd=Math.pow(varP,0.5);
for (i=0;i<3;i++) sum=sum+Math.pow( (ps[i]-meanP)/sd,3);
skewP=sum/3.0;

// round to 3 digits (for storing in the database)
meanPt=Math.round(meanP*1000)/1000;
varPt=Math.round(varP*1000)/1000;
skewPt=Math.round(skewP*1000)/1000;

// write to the database
record('meanP', meanPt);
record('varP', varPt);
record('skewP', skewPt);</script><!-- END Element 6 Type: 19-->
        
        <!-- START Element 7 Type: 18-->
        
        </div><div class="row"><div id="wrap7" style="display: none;">
        <script>
       
        
        </script>
        
        <div  id="button7">
        <div id="buttonclick7" class="btn btn-default btn-lg btn-block " style=" white-space:normal !important; word-wrap: break-word;" onclick="
        $(this).hide(); $('#buttonload7').show();
        if (additionalCheck7()) {
            hideError7();
            if (checkEntries()) toNextPage7();
            else  { $(this).show(); 
            $('#buttonload7').hide(); }
        } else {
         $(this).show(); 
         $('#buttonload7').hide();
         }
        ">Continue</div><div id="buttonload7" style="width: 100%; text-align: center; display: none;"><img src="<?php echo PATH;?>basis/buttonload.gif"></div><div id="field7_error" class="alert alert-danger" style="display: none; text-align: center;"></div><div id="field7_attempts" class="alert alert-warning" style="display: none; text-align: center;"></div></div><script>if(maxFalse!=null) {
            var numFails=quizFail(playerNr,1);  
            $('#field7_attempts').html('Attempts left to answer the control questions: '+(maxFalse-numFails));
            $('#field7_attempts').show();
        
        }
        function showError7(text) {
            var errorfield= $('#field7_error');
            errorfield.show();
            errorfield.html(text);
        
        }
        
        function hideError7() {
            $('#field7_error').hide();
        }
       
        
        

        if (typeof window.showNext === 'undefined') {
            window.showNext = function(url, nextstage, stageNr) {
                var timeRecName = "time_" + stageNr;
                var timeOnThisPage = getServerTime() - tStart;
                setValue(timeRecName, timeOnThisPage);
                if (nextstage==popup) { myPopup(url);}
                else { location.replace(url); }
            }
        }


        

        var checker;
        
        function checkEntries() {
           checker=0;

            var numEntries = document.forms[0].length;
            var numValuesExpected=0;

            for (var i=0; i<numEntries; i++)
            {
                var name = "checkValue_" + document.forms[0][i].id;
                if (document.forms[0][i].id!="")
                {                   
                    window[name](); /* this is a generic function calling the checker for the variable "name"  */
                    ++numValuesExpected;
                 };

            }
           if (checker==numValuesExpected) return true;
           else {
                checkFail();
                return false;
            }
        }
        
        function additionalCheck7() {if (v === 0){ 
    showError7('Please indicate your estimate for this round by moving the slider handle.') ;
    return false;
    }

setValue('secondEstimate',v);

           return true;
        }

       



        function checkFail() {} function toNextPage7() {
            if (loopEnd==32751) { showNext('wait32751.php?session_index=<?php echo $_SESSION[sessionID];?>',32752,32751);}
            else {showNext('stage32752.php?session_index=<?php echo $_SESSION[sessionID];?>',32752,32751);}

            };</script></div><script>if((true)) { $('#wrap7').show(); $('#buttonclick7').addClass('buttonclick');} </script><!-- END Element 7 Type: 18-->
        
        </div><script>setInterval(function(){ if (true) $('#wrap3').show();if (!(true)) $('#wrap3').hide();if (true) $('#wrap4').show();if (!(true)) $('#wrap4').hide();if (true) $('#wrap7').show();if (!(true)) $('#wrap7').hide(); }, 100);</script><script>countdownTimer(TimeOut, '_timeoutDecision.php?session_index=<?php echo $_SESSION[sessionID];?>',true);</script></form></div></body></html>