<html>
        <head>
        <?php
  
        include("_projectID.php");
        session_start();
	    $_SESSION['projectID']=PROJECTID;
	    include(PATH."basis/LIONESS.php");
	    ?>

        <link href="<?php echo PATH;?>basis/newlayout.css" rel="stylesheet" type="text/css"  />
        <link href="<?php echo PATH;?>basis/newlayout_bootstrap.css" rel="stylesheet" type="text/css"  />
        <link href="<?php echo PATH;?>basis/grid.css" rel="stylesheet" type="text/css"  /><title>questionnaire 3</title>

        <script> var v={}; var wronganswers={};var maxFalse = null;
        var firstStageExp = <?php echo json_encode(FIRSTPAGE . ".php"); ?>;
        var thisPage = <?php echo json_encode($thisPage); ?>;
      
        pageRefreshed=0;
        var loopBegin = "stage" + loopStart + ".php";
        var afterLoopEnd = 32754;
        if (thisPage == firstStageExp || (thisPage==loopBegin && period > 1) || loopEnd==afterLoopEnd) firstStage();
        /* if (thisPage == firstStageExp || thisPage==loopBegin || loopEnd==afterLoopEnd) firstStage(); */
        TimeOut=null;
        function skipStage() {
         location.replace('wait32755.php?session_index=<?php echo $_SESSION[sessionID];?>');
        }
        $(document).ready(function(){
        if (bot) { document.getElementsByClassName("buttonclick")[0].click(); }
        });
        
        </script>
        </head>
        <body class="container" style="width: 100%; padding-left: 5%; padding-right: 5%; padding-top: 1%;"><form autocomplete="off"><div class="row"><!-- START Element 1 Type: 19-->
        
        </div><div class="row">
        <script></script><!-- END Element 1 Type: 19-->
        
        <!-- START Element 2 Type: 1-->
        
        </div><div class="row"><div id="wrap2" style="display: none;"><div class="btnbox2 paddlr" style="text-align: center"><h3>Questionnaire 3 of 5</h3><p>Below you find 8 statements about yourself. <br>Please indicate for each statement to what extent you identify with it. </p></div>
        </div><script>if((true)) { $('#wrap2').show(); } </script><!-- END Element 2 Type: 1-->
        
        <!-- START Element 3 Type: 21-->
        
        </div><div class="row"><div id="wrap3" style="display: none;"><div class="btnbox2"><div class="form-group"><label><b>1. I&#039;d rather depend on myself than others. </b></label><table class="table"
         rules="none" style="margin-left:auto;margin-right:auto;"><tr><td style="padding: 10px; text-align: right; font-size: small;vertical-align: bottom;">never or definitely no</td><td style="text-align: center;"><label class="checkbox-inline"><input  type="radio" name="3" id="field3" value="1"

            onclick="indiv1=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="3" id="field3" value="2"

            onclick="indiv1=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="3" id="field3" value="3"

            onclick="indiv1=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="3" id="field3" value="4"

            onclick="indiv1=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="3" id="field3" value="5"

            onclick="indiv1=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="3" id="field3" value="6"

            onclick="indiv1=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="3" id="field3" value="7"

            onclick="indiv1=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="3" id="field3" value="8"

            onclick="indiv1=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="3" id="field3" value="9"

            onclick="indiv1=this.value;"
            ></label><td style="padding: 10px; text-align: left;font-size: small; vertical-align: bottom; " >always or definitely yes</td></tr></table></div><div id="field3_noEntry" class="messagefield3 alert alert-danger" style="display: none;">Please indicate your response </div><div id="field3_notcorrect" class="messagefield3 alert alert-danger" style="display: none;">The value you entered is not correct.</div></div><script>var indiv1=null;            

                  var k=0;

                  function checkValue_field3() {
                 var label="indiv1";var min=1;var max=9;var labelleft="never or definitely no";var labelright="always or definitely yes";var required=1;var correct=null;if(!(true)) {
                  checker=checker+1;
                } else {
                    k++;
                     if (bot) { 
                       if (correct != null) { value = correct; }
                        else if (typeof bot_indiv1 !== 'undefined') { value=bot_indiv1; }
                        else { value=Math.floor(Math.random()*max)+min; }
                    }
                    else { value=$("input[name=3]:checked").val(); }
                    
                    $('.messagefield3').hide();
                       allcorrect=checker+1;
                      /* check if any entry has been made */
                      if ((isNaN(value) || value == "") && required==1) {
                          $('#field3_noEntry').show();
                      }
                      else if (value!=correct && correct != null && required!=0) {
                            $('#field3_notcorrect').show();
                        } 
                      else {
                          
           
                                 record("indiv1", value);
                                 checker = checker+1;
                             }
                             
                             if (allcorrect!=checker) {
                      wronganswers['indiv1']=1;
                   } else wronganswers['indiv1']=0;    
                         }
                    
                    
                }
              </script></div></div></div></div><script>if((true)) { $('#wrap3').show(); } </script><!-- END Element 3 Type: 21-->
        
        <!-- START Element 4 Type: 21-->
        
        </div><div class="row"><div id="wrap4" style="display: none;"><div class="btnbox2"><div class="form-group"><label><b>4.  I rely on myself most of the time; I rarely rely on others. </b></label><table class="table"
         rules="none" style="margin-left:auto;margin-right:auto;"><tr><td style="padding: 10px; text-align: right; font-size: small;vertical-align: bottom;">never or definitely no</td><td style="text-align: center;"><label class="checkbox-inline"><input  type="radio" name="4" id="field4" value="1"

            onclick="indiv2=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="4" id="field4" value="2"

            onclick="indiv2=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="4" id="field4" value="3"

            onclick="indiv2=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="4" id="field4" value="4"

            onclick="indiv2=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="4" id="field4" value="5"

            onclick="indiv2=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="4" id="field4" value="6"

            onclick="indiv2=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="4" id="field4" value="7"

            onclick="indiv2=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="4" id="field4" value="8"

            onclick="indiv2=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="4" id="field4" value="9"

            onclick="indiv2=this.value;"
            ></label><td style="padding: 10px; text-align: left;font-size: small; vertical-align: bottom; " >always or definitely yes</td></tr></table></div><div id="field4_noEntry" class="messagefield4 alert alert-danger" style="display: none;">Please indicate your response </div><div id="field4_notcorrect" class="messagefield4 alert alert-danger" style="display: none;">The value you entered is not correct.</div></div><script>var indiv2=null;            

                  var k=0;

                  function checkValue_field4() {
                 var label="indiv2";var min=1;var max=9;var labelleft="never or definitely no";var labelright="always or definitely yes";var required=1;var correct=null;if(!(true)) {
                  checker=checker+1;
                } else {
                    k++;
                     if (bot) { 
                       if (correct != null) { value = correct; }
                        else if (typeof bot_indiv2 !== 'undefined') { value=bot_indiv2; }
                        else { value=Math.floor(Math.random()*max)+min; }
                    }
                    else { value=$("input[name=4]:checked").val(); }
                    
                    $('.messagefield4').hide();
                       allcorrect=checker+1;
                      /* check if any entry has been made */
                      if ((isNaN(value) || value == "") && required==1) {
                          $('#field4_noEntry').show();
                      }
                      else if (value!=correct && correct != null && required!=0) {
                            $('#field4_notcorrect').show();
                        } 
                      else {
                          
           
                                 record("indiv2", value);
                                 checker = checker+1;
                             }
                             
                             if (allcorrect!=checker) {
                      wronganswers['indiv2']=1;
                   } else wronganswers['indiv2']=0;    
                         }
                    
                    
                }
              </script></div></div></div></div><script>if((true)) { $('#wrap4').show(); } </script><!-- END Element 4 Type: 21-->
        
        <!-- START Element 5 Type: 21-->
        
        </div><div class="row"><div id="wrap5" style="display: none;"><div class="btnbox2"><div class="form-group"><label><b>5.  I often do "my own thing".</b></label><table class="table"
         rules="none" style="margin-left:auto;margin-right:auto;"><tr><td style="padding: 10px; text-align: right; font-size: small;vertical-align: bottom;">never or definitely no</td><td style="text-align: center;"><label class="checkbox-inline"><input  type="radio" name="5" id="field5" value="1"

            onclick="indiv3=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="5" id="field5" value="2"

            onclick="indiv3=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="5" id="field5" value="3"

            onclick="indiv3=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="5" id="field5" value="4"

            onclick="indiv3=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="5" id="field5" value="5"

            onclick="indiv3=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="5" id="field5" value="6"

            onclick="indiv3=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="5" id="field5" value="7"

            onclick="indiv3=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="5" id="field5" value="8"

            onclick="indiv3=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="5" id="field5" value="9"

            onclick="indiv3=this.value;"
            ></label><td style="padding: 10px; text-align: left;font-size: small; vertical-align: bottom; " >always or definitely yes</td></tr></table></div><div id="field5_noEntry" class="messagefield5 alert alert-danger" style="display: none;">Please indicate your response </div><div id="field5_notcorrect" class="messagefield5 alert alert-danger" style="display: none;">The value you entered is not correct.</div></div><script>var indiv3=null;            

                  var k=0;

                  function checkValue_field5() {
                 var label="indiv3";var min=1;var max=9;var labelleft="never or definitely no";var labelright="always or definitely yes";var required=1;var correct=null;if(!(true)) {
                  checker=checker+1;
                } else {
                    k++;
                     if (bot) { 
                       if (correct != null) { value = correct; }
                        else if (typeof bot_indiv3 !== 'undefined') { value=bot_indiv3; }
                        else { value=Math.floor(Math.random()*max)+min; }
                    }
                    else { value=$("input[name=5]:checked").val(); }
                    
                    $('.messagefield5').hide();
                       allcorrect=checker+1;
                      /* check if any entry has been made */
                      if ((isNaN(value) || value == "") && required==1) {
                          $('#field5_noEntry').show();
                      }
                      else if (value!=correct && correct != null && required!=0) {
                            $('#field5_notcorrect').show();
                        } 
                      else {
                          
           
                                 record("indiv3", value);
                                 checker = checker+1;
                             }
                             
                             if (allcorrect!=checker) {
                      wronganswers['indiv3']=1;
                   } else wronganswers['indiv3']=0;    
                         }
                    
                    
                }
              </script></div></div></div></div><script>if((true)) { $('#wrap5').show(); } </script><!-- END Element 5 Type: 21-->
        
        <!-- START Element 6 Type: 21-->
        
        </div><div class="row"><div id="wrap6" style="display: none;"><div class="btnbox2"><div class="form-group"><label><b>8. My personal identity, independent of others, is very important to me. </b></label><table class="table"
         rules="none" style="margin-left:auto;margin-right:auto;"><tr><td style="padding: 10px; text-align: right; font-size: small;vertical-align: bottom;">never or definitely no</td><td style="text-align: center;"><label class="checkbox-inline"><input  type="radio" name="6" id="field6" value="1"

            onclick="indiv4=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="6" id="field6" value="2"

            onclick="indiv4=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="6" id="field6" value="3"

            onclick="indiv4=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="6" id="field6" value="4"

            onclick="indiv4=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="6" id="field6" value="5"

            onclick="indiv4=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="6" id="field6" value="6"

            onclick="indiv4=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="6" id="field6" value="7"

            onclick="indiv4=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="6" id="field6" value="8"

            onclick="indiv4=this.value;"
            ></label><label class="checkbox-inline"><input  type="radio" name="6" id="field6" value="9"

            onclick="indiv4=this.value;"
            ></label><td style="padding: 10px; text-align: left;font-size: small; vertical-align: bottom; " >always or definitely yes</td></tr></table></div><div id="field6_noEntry" class="messagefield6 alert alert-danger" style="display: none;">Please indicate your response </div><div id="field6_notcorrect" class="messagefield6 alert alert-danger" style="display: none;">The value you entered is not correct.</div></div><script>var indiv4=null;            

                  var k=0;

                  function checkValue_field6() {
                 var label="indiv4";var min=1;var max=9;var labelleft="never or definitely no";var labelright="always or definitely yes";var required=1;var correct=null;if(!(true)) {
                  checker=checker+1;
                } else {
                    k++;
                     if (bot) { 
                       if (correct != null) { value = correct; }
                        else if (typeof bot_indiv4 !== 'undefined') { value=bot_indiv4; }
                        else { value=Math.floor(Math.random()*max)+min; }
                    }
                    else { value=$("input[name=6]:checked").val(); }
                    
                    $('.messagefield6').hide();
                       allcorrect=checker+1;
                      /* check if any entry has been made */
                      if ((isNaN(value) || value == "") && required==1) {
                          $('#field6_noEntry').show();
                      }
                      else if (value!=correct && correct != null && required!=0) {
                            $('#field6_notcorrect').show();
                        } 
                      else {
                          
           
                                 record("indiv4", value);
                                 checker = checker+1;
                             }
                             
                             if (allcorrect!=checker) {
                      wronganswers['indiv4']=1;
                   } else wronganswers['indiv4']=0;    
                         }
                    
                    
                }
              </script></div></div></div></div><script>if((true)) { $('#wrap6').show(); } </script><!-- END Element 6 Type: 21-->
        
        <!-- START Element 7 Type: 18-->
        
        </div><div class="row"><div id="wrap7" style="display: none;">
        <script>
       
        
        </script>
        
        <div  id="button7">
        <div id="buttonclick7" class="btn btn-default btn-lg btn-block " style=" white-space:normal !important; word-wrap: break-word;" onclick="
        $(this).hide(); $('#buttonload7').show();
        if (additionalCheck7()) {
            hideError7();
            if (checkEntries()) toNextPage7();
            else  { $(this).show(); 
            $('#buttonload7').hide(); }
        } else {
         $(this).show(); 
         $('#buttonload7').hide();
         }
        ">Continue</div><div id="buttonload7" style="width: 100%; text-align: center; display: none;"><img src="<?php echo PATH;?>basis/buttonload.gif"></div><div id="field7_error" class="alert alert-danger" style="display: none; text-align: center;"></div><div id="field7_attempts" class="alert alert-warning" style="display: none; text-align: center;"></div></div><script>if(maxFalse!=null) {
            var numFails=quizFail(playerNr,1);  
            $('#field7_attempts').html('Attempts left to answer the control questions: '+(maxFalse-numFails));
            $('#field7_attempts').show();
        
        }
        function showError7(text) {
            var errorfield= $('#field7_error');
            errorfield.show();
            errorfield.html(text);
        
        }
        
        function hideError7() {
            $('#field7_error').hide();
        }
       
        
        

        if (typeof window.showNext === 'undefined') {
            window.showNext = function(url, nextstage, stageNr) {
                var timeRecName = "time_" + stageNr;
                var timeOnThisPage = getServerTime() - tStart;
                setValue(timeRecName, timeOnThisPage);
                if (nextstage==popup) { myPopup(url);}
                else { location.replace(url); }
            }
        }


        

        var checker;
        
        function checkEntries() {
           checker=0;

            var numEntries = document.forms[0].length;
            var numValuesExpected=0;

            for (var i=0; i<numEntries; i++)
            {
                var name = "checkValue_" + document.forms[0][i].id;
                if (document.forms[0][i].id!="")
                {                   
                    window[name](); /* this is a generic function calling the checker for the variable "name"  */
                    ++numValuesExpected;
                 };

            }
           if (checker==numValuesExpected) return true;
           else {
                checkFail();
                return false;
            }
        }
        
        function additionalCheck7() {

           return true;
        }

       



        function checkFail() {} function toNextPage7() {
            if (loopEnd==32755) { showNext('wait32755.php?session_index=<?php echo $_SESSION[sessionID];?>',32756,32755);}
            else {showNext('stage32756.php?session_index=<?php echo $_SESSION[sessionID];?>',32756,32755);}

            };</script></div><script>if((true)) { $('#wrap7').show(); $('#buttonclick7').addClass('buttonclick');} </script><!-- END Element 7 Type: 18-->
        
        </div><script>setInterval(function(){ if (true) $('#wrap2').show();if (!(true)) $('#wrap2').hide();if (true) $('#wrap3').show();if (!(true)) $('#wrap3').hide();if (true) $('#wrap4').show();if (!(true)) $('#wrap4').hide();if (true) $('#wrap5').show();if (!(true)) $('#wrap5').hide();if (true) $('#wrap6').show();if (!(true)) $('#wrap6').hide();if (true) $('#wrap7').show();if (!(true)) $('#wrap7').hide(); }, 100);</script></form></div></body></html>