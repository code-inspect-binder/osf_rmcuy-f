<html>
        <head>
        <?php
  
        include("_projectID.php");
        session_start();
	    $_SESSION['projectID']=PROJECTID;
	    include(PATH."basis/LIONESS.php");
	    ?>

        <link href="<?php echo PATH;?>basis/newlayout.css" rel="stylesheet" type="text/css"  />
        <link href="<?php echo PATH;?>basis/newlayout_bootstrap.css" rel="stylesheet" type="text/css"  />
        <link href="<?php echo PATH;?>basis/grid.css" rel="stylesheet" type="text/css"  /><title>welcome</title>

        <script> var v={}; var wronganswers={};var maxFalse = null;
        var firstStageExp = <?php echo json_encode(FIRSTPAGE . ".php"); ?>;
        var thisPage = <?php echo json_encode($thisPage); ?>;
      
        pageRefreshed=0;
        var loopBegin = "stage" + loopStart + ".php";
        var afterLoopEnd = null;
        if (thisPage == firstStageExp || (thisPage==loopBegin && period > 1) || loopEnd==afterLoopEnd) firstStage();
        /* if (thisPage == firstStageExp || thisPage==loopBegin || loopEnd==afterLoopEnd) firstStage(); */
        TimeOut=null;
        function skipStage() {
         location.replace('wait32725.php?session_index=<?php echo $_SESSION[sessionID];?>');
        }
        $(document).ready(function(){
        if (bot) { document.getElementsByClassName("buttonclick")[0].click(); }
        });
        
        </script>
        </head>
        <body class="container" style="width: 100%; padding-left: 5%; padding-right: 5%; padding-top: 1%;"><form autocomplete="off"><div class="row"><!-- START Element 1 Type: 19-->
        
        </div><div class="row">
        <script>//store all experimental variables into server
record('relevant_decI',0); 
record('relevant_decII',0);
record('relevant_decIII',0);
record('EarningsI',0);
record('EarningsII',0);
record('EarningsIII',0);
record('nAnimals',0);
record('animalName', 0);
record('treatment',0);
record('firstEstimate',0);
record('secondEstimate',0);
record('p1',0);
record('p2',0);
record('p3',0);
record('meanP', 0);
record('varP', 0);
record('skewP', 0);
record('orderofTasks',0);
record('counterI', 1);
record('counterII', 1);
record('counterIII', 1);
record('4peerest1',0);
record('4peerest2',0);
record('4peerest3',0);
record('4peerest4',0);
record('4peerest5',0);


// set participation fee to string
feeT = '$'+parseFloat(participationFee).toFixed(2);


// select random rounds for payment
rnd_decI = 1 + Math.floor(Math.random() * 5); //
rnd_decII = 1 + Math.floor(Math.random() * 30); //
rnd_decIII = 1 + Math.floor(Math.random() * 5); //


setValue('relevant_decI', rnd_decI);
setValue('relevant_decII', rnd_decII);
setValue('relevant_decIII', rnd_decIII);</script><!-- END Element 1 Type: 19-->
        
        <!-- START Element 2 Type: 19-->
        
        </div><div class="row">
        <script>//arrays of real estimates from which we will draw the first estimate in condition 7
var e1 = [86,35,44,58,50,72,67,40,33,95,80,55,62,49,44,50,39,50,71,65,40,80,54,43,33,45,40,90,65,35,47,76,53,67,54,66,60,55,40,55,43,67,45,53,43,42,32,51,77,75,51,31,38,60,41,59,28,70,45,65,26,85,56,55,53,44,0,48,69,40,44,59,75,22,48,35,34,49,50,31,66,47,36,56,57,35,39,63,70,23,39,56,62,36,70,38,25,76,98,60,60];
e2 = [59,35,65,37,50,66,55,72,63,83,120,75,68,48,57,65,48,80,53,75,35,83,85,96,32,50,67,85,70,45,75,64,64,48,62,53,33,94,45,50,70,81,46,53,64,75,56,50,95,90,55,51,54,48,67,90,64,105,46,80,30,112,38,45,57,71,65,55,70,44,72,83,75,34,42,40,31,69,50,30,82,72,56,64,36,42,38,89,105,41,66,75,72,60,80,44,25,70,79,77,77];
e3 = [130,59,74,84,80,91,100,69,83,115,133,73,110,82,38,76,70,94,92,90,50,140,75,96,61,80,90,86,54,100,60,86,110,97,76,77,87,145,70,90,81,91,78,49,106,82,89,70,93,93,59,69,73,62,46,84,52,105,65,85,43,106,98,55,114,119,80,131,78,76,70,73,105,33,71,110,47,92,70,46,106,103,116,68,54,62,82,94,113,52,84,102,82,76,110,58,45,82,110,93,93];
e4 = [117,46,62,87,70,91,67,92,59,96,140,85,85,55,74,61,62,75,87,105,85,115,81,103,64,65,88,99,66,64,81,91,110,78,78,44,79,78,60,70,84,88,86,106,85,86,78,79,140,100,64,87,59,59,88,117,52,115,100,80,47,71,94,45,91,104,80,62,75,56,65,97,80,31,63,75,65,87,60,40,55,106,90,62,69,65,54,99,80,41,77,108,121,74,101,68,45,52,64,85,85];
e5 = [64,45,46,54,40,49,56,48,45,74,86,41,80,47,31,56,30,72,64,60,54,74,45,59,47,55,47,89,54,38,60,41,64,64,48,50,67,52,55,60,66,46,71,42,53,54,36,43,0,56,53,18,34,69,44,60,19,60,56,45,27,61,58,31,70,39,36,66,75,52,48,48,70,40,40,50,40,56,50,22,88,64,54,49,49,32,43,60,60,52,39,44,70,39,98,66,35,60,60,58,58];

//draw randomn number from each distribution to use as previous estimates in condition 7
var prev_est1 = e1[Math.floor(Math.random() * e1.length)];
var prev_est2 = e2[Math.floor(Math.random() * e2.length)];
var prev_est3 = e3[Math.floor(Math.random() * e3.length)];
var prev_est4 = e4[Math.floor(Math.random() * e4.length)];
var prev_est5 = e5[Math.floor(Math.random() * e5.length)];

    
      
setValue('4peerest1',prev_est1);
setValue('4peerest2',prev_est2);
setValue('4peerest3',prev_est3);
setValue('4peerest4',prev_est4);
setValue('4peerest5',prev_est5);</script><!-- END Element 2 Type: 19-->
        
        <!-- START Element 3 Type: 1-->
        
        </div><div class="row"><div id="wrap3" style="display: none;"><div class="btnbox2 paddlr" style="text-align: center"><h3>Welcome
</h3><p>In this HIT we ask you to complete <b>three tasks </b>(Task I, Task II and Task III).<br><span style="background-color: initial;">During these tasks you can earn points. The number of points you earn will depend on your responses</span><span style="background-color: initial;">.&nbsp;<br>In each task, you can earn up to <b>100 points.</b></span></p><p>At the end of this HIT, your points from Task I, Task II and Task III will be added up and converted into your bonus (<b>100 points = $1.00</b>).&nbsp;</p><p><span style="background-color: initial;">Your bonus will be paid on top of your guaranteed participation fee of <b><script>document.write(feeT)</script></b>.&nbsp;<br></span><span style="background-color: initial;">Upon completion, you will receive a random code to collect your payment on MTurk.&nbsp;</span><span style="background-color: initial;"></span></p><p><span style="background-color: initial;">In total, this HIT will take about 30-40 minutes. Please complete it without interruptions.<br>We finalize this HIT with a brief questionnaire.</span></p><p>Click below to proceed to the task instructions.
<br><span style="background-color: initial;">Please read these instructions carefully.</span></p><p></p></div>
        </div><script>if((true)) { $('#wrap3').show(); } </script><!-- END Element 3 Type: 1-->
        
        <!-- START Element 4 Type: 18-->
        
        </div><div class="row"><div id="wrap4" style="display: none;">
        <script>
       
        
        </script>
        
        <div  id="button4">
        <div id="buttonclick4" class="btn btn-default btn-lg btn-block " style=" white-space:normal !important; word-wrap: break-word;" onclick="
        $(this).hide(); $('#buttonload4').show();
        if (additionalCheck4()) {
            hideError4();
            if (checkEntries()) toNextPage4();
            else  { $(this).show(); 
            $('#buttonload4').hide(); }
        } else {
         $(this).show(); 
         $('#buttonload4').hide();
         }
        ">Continue</div><div id="buttonload4" style="width: 100%; text-align: center; display: none;"><img src="<?php echo PATH;?>basis/buttonload.gif"></div><div id="field4_error" class="alert alert-danger" style="display: none; text-align: center;"></div><div id="field4_attempts" class="alert alert-warning" style="display: none; text-align: center;"></div></div><script>if(maxFalse!=null) {
            var numFails=quizFail(playerNr,1);  
            $('#field4_attempts').html('Attempts left to answer the control questions: '+(maxFalse-numFails));
            $('#field4_attempts').show();
        
        }
        function showError4(text) {
            var errorfield= $('#field4_error');
            errorfield.show();
            errorfield.html(text);
        
        }
        
        function hideError4() {
            $('#field4_error').hide();
        }
       
        
        

        if (typeof window.showNext === 'undefined') {
            window.showNext = function(url, nextstage, stageNr) {
                var timeRecName = "time_" + stageNr;
                var timeOnThisPage = getServerTime() - tStart;
                setValue(timeRecName, timeOnThisPage);
                if (nextstage==popup) { myPopup(url);}
                else { location.replace(url); }
            }
        }


        

        var checker;
        
        function checkEntries() {
           checker=0;

            var numEntries = document.forms[0].length;
            var numValuesExpected=0;

            for (var i=0; i<numEntries; i++)
            {
                var name = "checkValue_" + document.forms[0][i].id;
                if (document.forms[0][i].id!="")
                {                   
                    window[name](); /* this is a generic function calling the checker for the variable "name"  */
                    ++numValuesExpected;
                 };

            }
           if (checker==numValuesExpected) return true;
           else {
                checkFail();
                return false;
            }
        }
        
        function additionalCheck4() {

           return true;
        }

       



        function checkFail() {} function toNextPage4() {
            if (loopEnd==32725) { showNext('wait32725.php?session_index=<?php echo $_SESSION[sessionID];?>',32726,32725);}
            else {showNext('stage32726.php?session_index=<?php echo $_SESSION[sessionID];?>',32726,32725);}

            };</script></div><script>if((true)) { $('#wrap4').show(); $('#buttonclick4').addClass('buttonclick');} </script><!-- END Element 4 Type: 18-->
        
        </div><script>setInterval(function(){ if (true) $('#wrap3').show();if (!(true)) $('#wrap3').hide();if (true) $('#wrap4').show();if (!(true)) $('#wrap4').hide(); }, 100);</script></form></div></body></html>