<?php

include('_projectID.php');

$path=PATH."_begin.php";
$path2=PATH."basis/sessionStart.php";
include($path2);
$_SESSION['projectID']=PROJECTID;

include($path);
setcookie('projectID',PROJECTID);



?>