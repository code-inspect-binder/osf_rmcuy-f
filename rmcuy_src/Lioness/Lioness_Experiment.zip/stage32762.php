<html>
        <head>
        <?php
  
        include("_projectID.php");
        session_start();
	    $_SESSION['projectID']=PROJECTID;
	    include(PATH."basis/LIONESS.php");
	    ?>

        <link href="<?php echo PATH;?>basis/newlayout.css" rel="stylesheet" type="text/css"  />
        <link href="<?php echo PATH;?>basis/newlayout_bootstrap.css" rel="stylesheet" type="text/css"  />
        <link href="<?php echo PATH;?>basis/grid.css" rel="stylesheet" type="text/css"  /><title>Collect payment</title>

        <script> var v={}; var wronganswers={};var maxFalse = null;
        var firstStageExp = <?php echo json_encode(FIRSTPAGE . ".php"); ?>;
        var thisPage = <?php echo json_encode($thisPage); ?>;
      
        pageRefreshed=0;
        var loopBegin = "stage" + loopStart + ".php";
        var afterLoopEnd = 32761;
        if (thisPage == firstStageExp || (thisPage==loopBegin && period > 1) || loopEnd==afterLoopEnd) firstStage();
        /* if (thisPage == firstStageExp || thisPage==loopBegin || loopEnd==afterLoopEnd) firstStage(); */
        TimeOut=null;
        function skipStage() {
         location.replace('wait32762.php?session_index=<?php echo $_SESSION[sessionID];?>');
        }
        $(document).ready(function(){
        if (bot) { document.getElementsByClassName("buttonclick")[0].click(); }
        });
        
        </script>
        </head>
        <body class="container" style="width: 100%; padding-left: 5%; padding-right: 5%; padding-top: 1%;"><form autocomplete="off"><div class="row"><!-- START Element 1 Type: 19-->
        
        </div><div class="row">
        <script>//earnings parts
var earnI = getValue('decisions', 'playerNr='+playerNr+' and period='+1, 'EarningsI');
var earnII = getValue('decisions', 'playerNr='+playerNr+' and period='+1, 'EarningsII');
var earnIII = getValue('decisions', 'playerNr='+playerNr+' and period='+1, 'EarningsIII');

// total earnings
points = earnI + earnII + earnIII;

orderOfTasks = getInt('orderofTasks');
var earn1 = earnI;
var earn2 = earnII;
var earn3 = earnIII;

// sort earning order according to task order
if (orderOfTasks==2){
    earn1 = earnI;
    earn2 = earnIII;
    earn3 = earnII;
} else if (orderOfTasks==3){
    earn1 = earnII;
    earn2 = earnIII;
    earn3 = earnI;
} else if (orderOfTasks==4){
    earn1 = earnII;
    earn2 = earnI;
    earn3 = earnIII;
} else if (orderOfTasks==5){
    earn1 = earnIII;
    earn2 = earnII;
    earn3 = earnI;
} else if (orderOfTasks==6){
    earn1 = earnIII;
    earn2 = earnI;
    earn3 = earnII;
}

var dollars = points * exchangeRate;
dollars = Math.min(dollars, 3); // do not let payment go above 1,50
var dollarsT = '$'+dollars.toFixed(2);
setBonus(dollars);

var randomid = getInt('session', 'playerNr='+playerNr, 'relevantRandomid');
feeT = '$'+parseFloat(participationFee).toFixed(2);</script><!-- END Element 1 Type: 19-->
        
        <!-- START Element 2 Type: 1-->
        
        </div><div class="row"><div id="wrap2" style="display: none;"><div class="btnbox2 paddlr" style="text-align: center"><h3>Total earnings</h3>This is the end of this HIT.&nbsp;<span style="background-color: initial;">Your earnings are calculated by adding up your Points from Task I, Task II Task III:</span><p></p><p><script>document.write(earn1)</script> (from Task I) <i>plus </i><script>document.write(earn2)</script> (from Task II) <i>plus&nbsp;</i><script>document.write(earn3)</script> (from Task III)= <b><script>document.write(points)</script> Points</b>.</p><p>These Points are worth <b><script>document.write(dollarsT)</script></b>.&nbsp;<span style="background-color: initial;">This is your bonus for this HIT.<br></span><span style="background-color: initial;">Note that any bonus you earn will be paid on top of your guaranteed participation fee of </span><b style="background-color: initial;"><script>document.write(feeT)</script></b><span style="background-color: initial;">.&nbsp;</span><span style="background-color: initial;">&nbsp;</span></p><p>To collect your payment for the HIT you just completed, please fill out the below code on MTurk.</p><p><b><script>document.write(randomid)</script></b></p><p>Once you have done that, you can close this window.&nbsp;<br>Thank you for your participation, and we hope you enjoyed participating in our HIT.</p><p></p><p></p></div>
        </div><script>if((true)) { $('#wrap2').show(); } </script><!-- END Element 2 Type: 1-->
        
        </div><script>setInterval(function(){ if (true) $('#wrap2').show();if (!(true)) $('#wrap2').hide(); }, 100);</script></form></div></body></html>