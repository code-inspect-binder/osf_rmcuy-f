Drop table if exists  `e537g9265_globals`; CREATE TABLE `e537g9265_globals` (
                  `name` varchar(36) NOT NULL,
                  `value` TEXT NOT NULL
                );INSERT INTO `e537g9265_globals` (`name`, `value`) VALUES('active', '1'),('testMode', '0'),('totalPlayers', '200'),('groupSize', '1'),('numberPeriods', '1'),('loopStart', ''),('loopEnd', ''),('participationFee', '4.5'),('exchangeRate', '0.01'),('popup', 'null'),('dropoutHandling', '3'),('sortableMatching', '1'),('message0', 'This HIT is currently offline. You cannot participate at this time.'),('message1', 'According to our records, your device has already been connected to the server during this session. &lt;br&gt;                Participants are only allowed to enter a session once. Thank you for your understanding.'),('message2', 'We have sufficient participants for this HIT. &lt;br&gt;Unfortunately, you cannot participate at this time. &lt;br&gt;&lt;br&gt;                Thank you for your understanding.'),('message3', 'You are currently not logged in. You cannot participate in the HIT.'),('message4', 'Unfortunately, this HIT was terminated for a technical reason! &lt;br&gt;&lt;br&gt;&lt;br&gt;                You cannot continue. &lt;br&gt;&lt;br&gt;&lt;br&gt;                You will receive your guaranteed participation fee of $ $participationFee$.                To collect your earnings, please fill out this random code on MTurk.                &lt;br&gt;&lt;br&gt;&lt;b&gt;$randomid$&lt;/b&gt;.                &lt;br&gt;                Once you have filled out this code, you can close this window.                Thank you for your participation.'),('message5', 'You did not make a decision before the time was up. &lt;br&gt;&lt;br&gt; You have been removed from the HIT. &lt;br&gt;&lt;br&gt;                        You can close down this window.'),('message6', 'Unfortunately, one of the players in your group dropped out of the HIT! &lt;br&gt;&lt;br&gt;&lt;br&gt;                 You cannot continue. &lt;br&gt;&lt;br&gt;&lt;br&gt;You will receive your guaranteed participation fee of                  $ $participationFee$.                 To collect your earnings, please fill out this random code on MTurk.                 &lt;br&gt;&lt;br&gt;&lt;b&gt;$randomid$&lt;/b&gt;.                 &lt;br&gt;                 Once you have filled out this code, you can close this window.                 Thank you for your participation.'),('message7', 'As indicated in our HIT text on MTurk, our HIT does &lt;b&gt;not&lt;/b&gt; support Microsoft Internet Explorer. &lt;br&gt;                         Please return this HIT.                         &lt;br&gt;                         We apologise for any inconvenience caused.'),('message8', 'You did not answer the quiz correctly and were excluded from further participation                                               '),('img_size', '50'),('overlap_ratio', '0.6'),('border', '50');ALTER TABLE e537g9265_globals ADD PRIMARY KEY(`name`);DROP TABLE IF EXISTS `e537g9265_decisions`;CREATE TABLE IF NOT EXISTS `e537g9265_decisions` (
                  `playerNr` int(11),
                  `groupNr` int(11),
                  `subjectNr` int(11),
                  `period` int(11)
                  ,`relevant_decI`   TEXT,`relevant_decII`   TEXT,`relevant_decIII`   TEXT,`EarningsI`   TEXT,`EarningsII`   TEXT,`EarningsIII`   TEXT,`nAnimals`   TEXT,`animalName`   TEXT,`treatment`   TEXT,`firstEstimate`   TEXT,`secondEstimate`   TEXT,`p1`   TEXT,`p2`   TEXT,`p3`   TEXT,`meanP`   TEXT,`varP`   TEXT,`skewP`   TEXT,`orderofTasks`   TEXT,`counterI`   TEXT,`counterII`   TEXT,`counterIII`   TEXT,`4peerest1`   TEXT,`4peerest2`   TEXT,`4peerest3`   TEXT,`4peerest4`   TEXT,`4peerest5`   TEXT,`qR1`   TEXT,`qR2`   TEXT,`IOS`   TEXT,`conf1`   TEXT,`conf2`   TEXT,`conf3`   TEXT,`conf4`   TEXT,`conf5`   TEXT,`conf6`   TEXT,`conf7`   TEXT,`conf8`   TEXT,`conf9`   TEXT,`conf10`   TEXT,`conf11`   TEXT,`indiv1`   TEXT,`indiv2`   TEXT,`indiv3`   TEXT,`indiv4`   TEXT,`resistance_peer_influence_1`   TEXT,`resistance_peer_influence_2`   TEXT,`resistance_peer_influence_3`   TEXT,`resistance_peer_influence_4`   TEXT,`resistance_peer_influence_5`   TEXT,`resistance_peer_influence_6`   TEXT,`resistance_peer_influence_7`   TEXT,`resistance_peer_influence_8`   TEXT,`resistance_peer_influence_9`   TEXT,`resistance_peer_influence_10`   TEXT,`age`   TEXT,`gender`   TEXT,`time_32725` float ,`time_32726` float ,`time_32727` float ,`time_32728` float ,`time_32729` float ,`time_32730` float ,`time_32731` float ,`time_32732` float ,`time_32733` float ,`time_32734` float ,`time_32735` float ,`time_32736` float ,`time_32737` float ,`time_32738` float ,`time_32739` float ,`time_32740` float ,`time_32741` float ,`time_32742` float ,`time_32743` float ,`time_32744` float ,`time_32745` float ,`time_32746` float ,`time_32747` float ,`time_32748` float ,`time_32749` float ,`time_32750` float ,`time_32751` float ,`time_32752` float ,`time_32753` float ,`time_32754` float ,`time_32755` float ,`time_32756` float ,`time_32757` float ,`time_32758` float ,`time_32759` float ,`time_32760` float ,`time_32761` float ,`time_32762` float );ALTER TABLE e537g9265_decisions ADD PRIMARY KEY( `playerNr`, `period`);DROP TABLE IF EXISTS `e537g9265_logEvents`;CREATE TABLE IF NOT EXISTS `e537g9265_logEvents` (
                  `eventNr` int(11) NOT NULL AUTO_INCREMENT,
                  `groupNr` int(11) NOT NULL,
                  `playerNr` int(11) NOT NULL,
                  `timeEvent` varchar(256) NOT NULL,
                  `event` varchar(256) NOT NULL,
                  PRIMARY KEY(eventNr)
                );DROP TABLE IF EXISTS `e537g9265_core`;CREATE TABLE IF NOT EXISTS `e537g9265_core` (
                      `playerNr` int(11) NOT NULL AUTO_INCREMENT,                   
                      `groupNr` int(11) NOT NULL,
                      `subjectNr` int(11) NOT NULL,
                      `groupNrStart` int(11) NOT NULL,
                      `currentGroupSize` int(11) NOT NULL,
                      `period` int(11) NOT NULL,
                      `onPage` varchar(30) NOT NULL,
                      `connected` boolean,
                      `tStart` int(11) NOT NULL,
                      `lastActionTime` int(11) NOT NULL,
                      `ipaddress` varchar(99) NOT NULL,
                      `waitMore` int(11) NOT NULL,
                      `lobbyReady` boolean,
                      `enterLobby` INT(11),
                      `role` INT(11),`wait_32725ready` boolean,`wait_32726ready` boolean,`wait_32727ready` boolean,`wait_32728ready` boolean,`wait_32729ready` boolean,`wait_32730ready` boolean,`wait_32731ready` boolean,`wait_32732ready` boolean,`wait_32733ready` boolean,`wait_32734ready` boolean,`wait_32735ready` boolean,`wait_32736ready` boolean,`wait_32737ready` boolean,`wait_32738ready` boolean,`wait_32739ready` boolean,`wait_32740ready` boolean,`wait_32741ready` boolean,`wait_32742ready` boolean,`wait_32743ready` boolean,`wait_32744ready` boolean,`wait_32745ready` boolean,`wait_32746ready` boolean,`wait_32747ready` boolean,`wait_32748ready` boolean,`wait_32749ready` boolean,`wait_32750ready` boolean,`wait_32751ready` boolean,`wait_32752ready` boolean,`wait_32753ready` boolean,`wait_32754ready` boolean,`wait_32755ready` boolean,`wait_32756ready` boolean,`wait_32757ready` boolean,`wait_32758ready` boolean,`wait_32759ready` boolean,`wait_32760ready` boolean,`wait_32761ready` boolean,`wait_32762ready` boolean,`wait_lastInPeriod` boolean,
                      `periodReady` boolean,
                      `leftExperiment` boolean,
                      `experimentTerminated` boolean,
                      `groupAborted` boolean,
                      PRIMARY KEY (playerNr)
                    );DROP TABLE IF EXISTS `e537g9265_session`;CREATE TABLE IF NOT EXISTS `e537g9265_session` (
                  `playerNr` int(11) NOT NULL,
                  `randomid` VARCHAR(256) NOT NULL,
                  `randomidNotPlayed` VARCHAR(256)   NOT NULL,
                  `relevantRandomid` varchar(256) NOT NULL,
                  `participationAmount` decimal(11,2) NOT NULL,
                  `bonusAmount` decimal(11,2) NOT NULL,
                  `totalEarnings` decimal(11,2) NOT NULL,`qR1_fail`   int(11) DEFAULT 0,`qR2_fail`   int(11) DEFAULT 0,`quizFail` int(11) DEFAULT 0,
                    PRIMARY KEY (playerNr)
                  );TRUNCATE `e537g9265_session`;