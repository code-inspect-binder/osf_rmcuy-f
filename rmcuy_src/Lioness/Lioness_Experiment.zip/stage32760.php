<html>
        <head>
        <?php
  
        include("_projectID.php");
        session_start();
	    $_SESSION['projectID']=PROJECTID;
	    include(PATH."basis/LIONESS.php");
	    ?>

        <link href="<?php echo PATH;?>basis/newlayout.css" rel="stylesheet" type="text/css"  />
        <link href="<?php echo PATH;?>basis/newlayout_bootstrap.css" rel="stylesheet" type="text/css"  />
        <link href="<?php echo PATH;?>basis/grid.css" rel="stylesheet" type="text/css"  /><title>earnings TP</title>

        <script> var v={}; var wronganswers={};var maxFalse = null;
        var firstStageExp = <?php echo json_encode(FIRSTPAGE . ".php"); ?>;
        var thisPage = <?php echo json_encode($thisPage); ?>;
      
        pageRefreshed=0;
        var loopBegin = "stage" + loopStart + ".php";
        var afterLoopEnd = 32759;
        if (thisPage == firstStageExp || (thisPage==loopBegin && period > 1) || loopEnd==afterLoopEnd) firstStage();
        /* if (thisPage == firstStageExp || thisPage==loopBegin || loopEnd==afterLoopEnd) firstStage(); */
        TimeOut=null;
        function skipStage() {
         location.replace('wait32760.php?session_index=<?php echo $_SESSION[sessionID];?>');
        }
        $(document).ready(function(){
        if (bot) { document.getElementsByClassName("buttonclick")[0].click(); }
        });
        
        </script>
        </head>
        <body class="container" style="width: 100%; padding-left: 5%; padding-right: 5%; padding-top: 1%;"><form autocomplete="off"><div class="row"><!-- START Element 1 Type: 19-->
        
        </div><div class="row">
        <script>orderOfTasks=getInt('orderofTasks');
taskT = 'II';
if (orderOfTasks== 3 || orderOfTasks== 4  ) {
    taskT='I';
} else if (orderOfTasks== 2  || orderOfTasks== 6  ){
    taskT='III';  
}

//calculate how many periods there were before Task I
var addTrials = 5;
if (orderOfTasks== 3 || orderOfTasks== 4 ){
    addTrials= 0;
} else if (orderOfTasks== 2  || orderOfTasks== 6  ){
    addTrials= 10}
    
//calculate period to retrieve estimate in the results table
relevantRound = getValue('decisions', 'playerNr='+playerNr+' and period='+1, 'relevant_decII');
period = relevantRound + addTrials;
    
var animal_names =['ant', 'bee', 'flamingo', 'crane', 'cricket','ant', 'bee', 'flamingo', 'crane', 'cricket','ant', 'bee', 'flamingo', 'crane', 'cricket','ant', 'bee', 'flamingo', 'crane', 'cricket','ant', 'bee', 'flamingo', 'crane', 'cricket','ant', 'bee', 'flamingo', 'crane', 'cricket'];

//how many animals we show
var numbers = [98, 77, 98, 85, 84, 60, 98, 50, 62, 71, 88, 59, 93, 99, 58, 79, 50,
       69, 52, 97, 71, 97, 89, 93, 58, 53, 80, 58, 86, 70];


var thisCorr = numbers[relevantRound-1];
var relevantAnimal = animal_names[relevantRound-1];
relevantVarName = relevantAnimal;

//use period to get appropriate estimate in that round
var est = getValue('decisions', 'playerNr='+playerNr+' and period='+period, 'secondEstimate');

var deviation = Math.abs(est - thisCorr);
var subtraction = Math.min(100, 5 * deviation);
var points = Math.max(100 - deviation * 5, 0);
points = parseInt(points.toFixed(0));

//100 points are worth 1 dollar
var dollars = points * exchangeRate;

// do not let payment for 1 round go above that
dollars = Math.min(dollars,1); 
var dollarsT = '$'+dollars.toFixed(2);

var subtractionT = 'As a consequence, we subtract ' + deviation + ' x 5 = ' + subtraction + ' Points.';
if (deviation > 20) {
    subtractionT = 'As a consequence, we would have subtracted  ' + deviation + ' x 5 Points. <br>'
        subtractionT += 'However, as stated in the instructions, your number of Points cannot become negative, so we subtract 100 Points.';
    
}

setValue('decisions', 'playerNr='+playerNr+' and period='+1, 'earningsII', points);</script><!-- END Element 1 Type: 19-->
        
        <!-- START Element 2 Type: 1-->
        
        </div><div class="row"><div id="wrap2" style="display: none;"><div class="btnbox2 paddlr" style="text-align: center"><h3>Earnings Task <script>document.write(taskT)</script></h3>Your earnings for Task $task I$<span style="background-color: initial;">&nbsp;are calculated as follows.</span><p></p><p>The computer randomly selected round <b><script>document.write(relevantRound)</script></b>.<br>In that round, you estimated how many <b><script>document.write(relevantAnimal)</script>s</b> there were in the image.</p><p>Your estimate in that case was<b> <script>document.write(est)</script></b>.<br>The actual number of <script>document.write(relevantAnimal)</script>s in the image was <b><script>document.write(thisCorr)</script></b>.</p><p>This means that your estimate was&nbsp;<b><script>document.write(deviation)</script></b> off the actual number.<br><script>document.write(subtractionT)</script></p><p>You have earned 100 - <script>document.write(subtraction)</script> = <b><script>document.write(points)</script> points</b>. <br>These Points are worth <b><script>document.write(dollarsT)</script></b>.</p><p><span style="background-color: initial;">This is your bonus for this Task.&nbsp;</span><br></p><p>Click continue to see your bonus for the other tasks.</p><p></p><p></p></div>
        </div><script>if((true)) { $('#wrap2').show(); } </script><!-- END Element 2 Type: 1-->
        
        <!-- START Element 3 Type: 18-->
        
        </div><div class="row"><div id="wrap3" style="display: none;">
        <script>
       
        
        </script>
        
        <div  id="button3">
        <div id="buttonclick3" class="btn btn-default btn-lg btn-block btn-warning" style=" white-space:normal !important; word-wrap: break-word;" onclick="
        $(this).hide(); $('#buttonload3').show();
        if (additionalCheck3()) {
            hideError3();
            if (checkEntries()) toNextPage3();
            else  { $(this).show(); 
            $('#buttonload3').hide(); }
        } else {
         $(this).show(); 
         $('#buttonload3').hide();
         }
        ">Continue</div><div id="buttonload3" style="width: 100%; text-align: center; display: none;"><img src="<?php echo PATH;?>basis/buttonload.gif"></div><div id="field3_error" class="alert alert-danger" style="display: none; text-align: center;"></div><div id="field3_attempts" class="alert alert-warning" style="display: none; text-align: center;"></div></div><script>if(maxFalse!=null) {
            var numFails=quizFail(playerNr,1);  
            $('#field3_attempts').html('Attempts left to answer the control questions: '+(maxFalse-numFails));
            $('#field3_attempts').show();
        
        }
        function showError3(text) {
            var errorfield= $('#field3_error');
            errorfield.show();
            errorfield.html(text);
        
        }
        
        function hideError3() {
            $('#field3_error').hide();
        }
       
        
        

        if (typeof window.showNext === 'undefined') {
            window.showNext = function(url, nextstage, stageNr) {
                var timeRecName = "time_" + stageNr;
                var timeOnThisPage = getServerTime() - tStart;
                setValue(timeRecName, timeOnThisPage);
                if (nextstage==popup) { myPopup(url);}
                else { location.replace(url); }
            }
        }


        

        var checker;
        
        function checkEntries() {
           checker=0;

            var numEntries = document.forms[0].length;
            var numValuesExpected=0;

            for (var i=0; i<numEntries; i++)
            {
                var name = "checkValue_" + document.forms[0][i].id;
                if (document.forms[0][i].id!="")
                {                   
                    window[name](); /* this is a generic function calling the checker for the variable "name"  */
                    ++numValuesExpected;
                 };

            }
           if (checker==numValuesExpected) return true;
           else {
                checkFail();
                return false;
            }
        }
        
        function additionalCheck3() {

           return true;
        }

       



        function checkFail() {} function toNextPage3() {
            if (loopEnd==32760) { showNext('wait32760.php?session_index=<?php echo $_SESSION[sessionID];?>',32762,32760);}
            else {showNext('stage32762.php?session_index=<?php echo $_SESSION[sessionID];?>',32762,32760);}

            };</script></div><script>if((orderOfTasks == 2 || orderOfTasks == 6)) { $('#wrap3').show(); $('#buttonclick3').addClass('buttonclick');} </script><!-- END Element 3 Type: 18-->
        
        <!-- START Element 4 Type: 18-->
        
        </div><div class="row"><div id="wrap4" style="display: none;">
        <script>
       
        
        </script>
        
        <div  id="button4">
        <div id="buttonclick4" class="btn btn-default btn-lg btn-block btn-warning" style=" white-space:normal !important; word-wrap: break-word;" onclick="
        $(this).hide(); $('#buttonload4').show();
        if (additionalCheck4()) {
            hideError4();
            if (checkEntries()) toNextPage4();
            else  { $(this).show(); 
            $('#buttonload4').hide(); }
        } else {
         $(this).show(); 
         $('#buttonload4').hide();
         }
        ">Continue</div><div id="buttonload4" style="width: 100%; text-align: center; display: none;"><img src="<?php echo PATH;?>basis/buttonload.gif"></div><div id="field4_error" class="alert alert-danger" style="display: none; text-align: center;"></div><div id="field4_attempts" class="alert alert-warning" style="display: none; text-align: center;"></div></div><script>if(maxFalse!=null) {
            var numFails=quizFail(playerNr,1);  
            $('#field4_attempts').html('Attempts left to answer the control questions: '+(maxFalse-numFails));
            $('#field4_attempts').show();
        
        }
        function showError4(text) {
            var errorfield= $('#field4_error');
            errorfield.show();
            errorfield.html(text);
        
        }
        
        function hideError4() {
            $('#field4_error').hide();
        }
       
        
        

        if (typeof window.showNext === 'undefined') {
            window.showNext = function(url, nextstage, stageNr) {
                var timeRecName = "time_" + stageNr;
                var timeOnThisPage = getServerTime() - tStart;
                setValue(timeRecName, timeOnThisPage);
                if (nextstage==popup) { myPopup(url);}
                else { location.replace(url); }
            }
        }


        

        var checker;
        
        function checkEntries() {
           checker=0;

            var numEntries = document.forms[0].length;
            var numValuesExpected=0;

            for (var i=0; i<numEntries; i++)
            {
                var name = "checkValue_" + document.forms[0][i].id;
                if (document.forms[0][i].id!="")
                {                   
                    window[name](); /* this is a generic function calling the checker for the variable "name"  */
                    ++numValuesExpected;
                 };

            }
           if (checker==numValuesExpected) return true;
           else {
                checkFail();
                return false;
            }
        }
        
        function additionalCheck4() {

           return true;
        }

       



        function checkFail() {} function toNextPage4() {
            if (loopEnd==32760) { showNext('wait32760.php?session_index=<?php echo $_SESSION[sessionID];?>',32761,32760);}
            else {showNext('stage32761.php?session_index=<?php echo $_SESSION[sessionID];?>',32761,32760);}

            };</script></div><script>if((orderOfTasks == 1 || orderOfTasks == 3)) { $('#wrap4').show(); $('#buttonclick4').addClass('buttonclick');} </script><!-- END Element 4 Type: 18-->
        
        <!-- START Element 5 Type: 18-->
        
        </div><div class="row"><div id="wrap5" style="display: none;">
        <script>
       
        
        </script>
        
        <div  id="button5">
        <div id="buttonclick5" class="btn btn-default btn-lg btn-block btn-warning" style=" white-space:normal !important; word-wrap: break-word;" onclick="
        $(this).hide(); $('#buttonload5').show();
        if (additionalCheck5()) {
            hideError5();
            if (checkEntries()) toNextPage5();
            else  { $(this).show(); 
            $('#buttonload5').hide(); }
        } else {
         $(this).show(); 
         $('#buttonload5').hide();
         }
        ">Continue</div><div id="buttonload5" style="width: 100%; text-align: center; display: none;"><img src="<?php echo PATH;?>basis/buttonload.gif"></div><div id="field5_error" class="alert alert-danger" style="display: none; text-align: center;"></div><div id="field5_attempts" class="alert alert-warning" style="display: none; text-align: center;"></div></div><script>if(maxFalse!=null) {
            var numFails=quizFail(playerNr,1);  
            $('#field5_attempts').html('Attempts left to answer the control questions: '+(maxFalse-numFails));
            $('#field5_attempts').show();
        
        }
        function showError5(text) {
            var errorfield= $('#field5_error');
            errorfield.show();
            errorfield.html(text);
        
        }
        
        function hideError5() {
            $('#field5_error').hide();
        }
       
        
        

        if (typeof window.showNext === 'undefined') {
            window.showNext = function(url, nextstage, stageNr) {
                var timeRecName = "time_" + stageNr;
                var timeOnThisPage = getServerTime() - tStart;
                setValue(timeRecName, timeOnThisPage);
                if (nextstage==popup) { myPopup(url);}
                else { location.replace(url); }
            }
        }


        

        var checker;
        
        function checkEntries() {
           checker=0;

            var numEntries = document.forms[0].length;
            var numValuesExpected=0;

            for (var i=0; i<numEntries; i++)
            {
                var name = "checkValue_" + document.forms[0][i].id;
                if (document.forms[0][i].id!="")
                {                   
                    window[name](); /* this is a generic function calling the checker for the variable "name"  */
                    ++numValuesExpected;
                 };

            }
           if (checker==numValuesExpected) return true;
           else {
                checkFail();
                return false;
            }
        }
        
        function additionalCheck5() {

           return true;
        }

       



        function checkFail() {} function toNextPage5() {
            if (loopEnd==32760) { showNext('wait32760.php?session_index=<?php echo $_SESSION[sessionID];?>',32759,32760);}
            else {showNext('stage32759.php?session_index=<?php echo $_SESSION[sessionID];?>',32759,32760);}

            };</script></div><script>if((orderOfTasks == 4 || orderOfTasks == 5)) { $('#wrap5').show(); $('#buttonclick5').addClass('buttonclick');} </script><!-- END Element 5 Type: 18-->
        
        </div><script>setInterval(function(){ if (true) $('#wrap2').show();if (!(true)) $('#wrap2').hide();if (orderOfTasks == 2 || orderOfTasks == 6) $('#wrap3').show();if (!(orderOfTasks == 2 || orderOfTasks == 6)) $('#wrap3').hide();if (orderOfTasks == 1 || orderOfTasks == 3) $('#wrap4').show();if (!(orderOfTasks == 1 || orderOfTasks == 3)) $('#wrap4').hide();if (orderOfTasks == 4 || orderOfTasks == 5) $('#wrap5').show();if (!(orderOfTasks == 4 || orderOfTasks == 5)) $('#wrap5').hide(); }, 100);</script></form></div></body></html>